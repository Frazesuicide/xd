package at.shaderapfel.lobby;

import java.util.ArrayList;

import at.shaderapfel.lobby.commands.*;
import at.shaderapfel.lobby.interact.*;
import at.shaderapfel.lobby.utils.MySQL;
import at.shaderapfel.lobby.metrics.Metrics;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import at.shaderapfel.lobby.listener.Build;
import at.shaderapfel.lobby.listener.Chat;
import at.shaderapfel.lobby.listener.Damage;
import at.shaderapfel.lobby.listener.DropPickup;
import at.shaderapfel.lobby.listener.FoodLevel;
import at.shaderapfel.lobby.listener.InvClick;
import at.shaderapfel.lobby.listener.InvClickKleiderschrank;
import at.shaderapfel.lobby.listener.InvClose;
import at.shaderapfel.lobby.listener.Join;
import at.shaderapfel.lobby.listener.Move;
import at.shaderapfel.lobby.listener.Preprocess;
import at.shaderapfel.lobby.listener.QuitKick;
import at.shaderapfel.lobby.listener.Weather;
import at.shaderapfel.lobby.listener.jumppads;
import at.shaderapfel.lobby.methods.LocationAPI;
import at.shaderapfel.lobby.methods.methAutoMessengerScheduler;

public class Main extends JavaPlugin {

    public static Main instance;

    public MySQL mysql;

    public static String Server1Name;
    public static String Server2Name;
    public static String Server3Name;
    public static String Server4Name;
    public static String SilentHubName;

    public static Boolean Server1Activated;
    public static Boolean Server2Activated;
    public static Boolean Server3Activated;
    public static Boolean Server4Activated;
    public static Boolean SilentHubActivated;

    public static Boolean customItemEnabled;
    public static int customItemId;
    public static String customItemDisplayName;
    public static String customItemCmd;

    public static int compassid;
    public static int playerhiderid;
    public static int rankhiderid;
    public static int flymodeid;
    public static int nogadgetid;

    public static Boolean IsServer1;
    public static Boolean IsServer2;
    public static Boolean IsServer3;
    public static Boolean IsServer4;
    public static Boolean IsSilentHub;

    public static ArrayList<Player> buildmode = new ArrayList<>();
    public static ArrayList<Player> fly = new ArrayList<>();

    public static ArrayList<Player> playerhide = new ArrayList<>();
    public static ArrayList<Player> rankhidden = new ArrayList<>();
    public static ArrayList<Player> nickname = new ArrayList<>();

    public static ArrayList<Player> playersall = new ArrayList<>();
    public static ArrayList<Player> playersvip = new ArrayList<>();
    public static ArrayList<Player> playersnone = new ArrayList<>();

    public static ArrayList<Player> cooldown = new ArrayList<>();

    public static ArrayList<Player> enderpearl = new ArrayList<>();
    public static ArrayList<Player> jumpboost = new ArrayList<>();
    public static ArrayList<Player> mysticcannon = new ArrayList<>();
    public static ArrayList<Player> snowball = new ArrayList<>();

    public static ArrayList<Player> golddrops = new ArrayList<>();
    public static ArrayList<Player> reddrops = new ArrayList<>();

    public static ArrayList<Player> flametrail = new ArrayList<>();
    public static ArrayList<Player> lovetrail = new ArrayList<>();
    public static ArrayList<Player> smoketrail = new ArrayList<>();


    public static String joinMotd;


    public static Boolean gadgetsEnabled;
    public static Boolean profilEnabled;
    public static Boolean lobbyswitcherEnabled;


    public static String staffJoinBroadcast;

    public static String sqlhost;
    public static String sqluser;
    public static String sqlpassword;
    public static String sqldatabase;

    public static String tabheader;
    public static String tabfooter;

    public static String help1;
    public static String help2;
    public static String help3;
    public static String help4;
    public static String help5;
    public static String help6;
    public static String help7;
    public static String help8;

    public static String sbtitle;
    public static String sb1;
    public static String sb2;
    public static String sb3;
    public static String sb4;
    public static String sb5;
    public static String sb6;
    public static String sb7;
    public static String sb8;
    public static String sb9;
    public static String sb10;

    public static String servername;
    public static String teamspeakip;
    public static String prefix;
    public static String noperms;
    public static String gm0msg;
    public static String gm1msg;
    public static String gm2msg;
    public static String gm3msg;
    public static String gm0msgP;
    public static String gm1msgP;
    public static String gm2msgP;
    public static String gm3msgP;
    public static String unknowngm;
    public static String playernotfound;
    public static String youtubemsg;
    public static String tsmsg;
    public static String websitemsg;
    public static String shopmsg;
    public static String buildmodeon;
    public static String buildmodeoff;
    public static String buildmodeonother;
    public static String buildmodeoffother;
    public static String flymodeon;
    public static String flymodeoff;
    public static String flymodeonother;
    public static String flymodeoffother;
    public static String warpsuccessful;
    public static String warpfailed;
    public static String unknownwarp;
    public static String automsg1;
    public static String automsg2;
    public static String automsg3;
    public static String automsg4;
    public static String spawnsuccessful;
    public static String spawnfailed;
    public static String allplayer;
    public static String vipplayer;
    public static String noplayer;
    public static String weathersun;
    public static String weatherrain;
    public static String timeday;
    public static String timenight;
    public static String unknownweather;
    public static String unknowntime;
    public static String nickan;
    public static String nickaus;
    public static String silentlobbyan;
    public static String silentlobbyaus;
    public static String silentlobbychat;
    public static String unknownnick;
    public static String setgroup;
    public static String unknownsetgroup;
    public static String setgroupkickmsg;
    public static String tpself;
    public static String tpother;
    public static String unknowntp;
    public static String gadget;

    public static String friendscommand;

    public static String skullname1;
    public static String skullname2;
    public static String skullname3;
    public static String skullname4;
    public static String skullname5;
    public static String skullname6;
    public static String skullname7;
    public static String skullname8;
    public static String skullname9;
    public static String skullname10;
    public static String skullname11;
    public static String skullname12;
    public static String skullname13;
    public static String skullname14;
    public static String skullname15;
    public static String skullname16;
    public static String skullname17;
    public static String skullname18;
    public static String skullname19;
    public static String skullname20;
    public static String skullname21;

    public static String skullplayername1;
    public static String skullplayername2;
    public static String skullplayername3;
    public static String skullplayername4;
    public static String skullplayername5;
    public static String skullplayername6;
    public static String skullplayername7;
    public static String skullplayername8;
    public static String skullplayername9;
    public static String skullplayername10;
    public static String skullplayername11;
    public static String skullplayername12;
    public static String skullplayername13;
    public static String skullplayername14;
    public static String skullplayername15;
    public static String skullplayername16;
    public static String skullplayername17;
    public static String skullplayername18;
    public static String skullplayername19;
    public static String skullplayername20;
    public static String skullplayername21;

    public static String rankadmin;
    public static String rankdev;
    public static String ranksrmod;
    public static String rankmod;
    public static String ranksupporter;
    public static String rankbuilder;
    public static String rankyoutuber;
    public static String rankminiyoutuber;
    public static String rankultimate;
    public static String rankelite;
    public static String rankplus;
    public static String rankspieler;

    public static String rankadmintab;
    public static String rankdevtab;
    public static String ranksrmodtab;
    public static String rankmodtab;
    public static String ranksupportertab;
    public static String rankbuildertab;
    public static String rankyoutubertab;
    public static String rankminiyoutubertab;
    public static String rankultimatetab;
    public static String rankelitetab;
    public static String rankplustab;
    public static String rankspielertab;

    public static Material WarpItem1;
    public static String WarpItem1Name;
    public static Material WarpItem2;
    public static String WarpItem2Name;
    public static Material WarpItem3;
    public static String WarpItem3Name;
    public static Material WarpItem4;
    public static String WarpItem4Name;
    public static Material WarpItem5;
    public static String WarpItem5Name;
    public static Material WarpItem6;
    public static String WarpItem6Name;
    public static Material WarpItem7;
    public static String WarpItem7Name;
    public static Material WarpItem8;
    public static String WarpItem8Name;
    public static Material WarpItem9;
    public static String WarpItem9Name;
    public static Material WarpItem10;
    public static String WarpItem10Name;
    public static Material WarpItem11;
    public static String WarpItem11Name;
    public static Material WarpItem12;
    public static String WarpItem12Name;
    public static Material WarpItem13;
    public static String WarpItem13Name;
    public static Material WarpItem14;
    public static String WarpItem14Name;

    public static String WarpItem1WarpName;
    public static String WarpItem2WarpName;
    public static String WarpItem3WarpName;
    public static String WarpItem4WarpName;
    public static String WarpItem5WarpName;
    public static String WarpItem6WarpName;
    public static String WarpItem7WarpName;
    public static String WarpItem8WarpName;
    public static String WarpItem9WarpName;
    public static String WarpItem10WarpName;
    public static String WarpItem11WarpName;
    public static String WarpItem12WarpName;
    public static String WarpItem13WarpName;
    public static String WarpItem14WarpName;

    public static Boolean WarpItem1Enabled;
    public static Boolean WarpItem2Enabled;
    public static Boolean WarpItem3Enabled;
    public static Boolean WarpItem4Enabled;
    public static Boolean WarpItem5Enabled;
    public static Boolean WarpItem6Enabled;
    public static Boolean WarpItem7Enabled;
    public static Boolean WarpItem8Enabled;
    public static Boolean WarpItem9Enabled;
    public static Boolean WarpItem10Enabled;
    public static Boolean WarpItem11Enabled;
    public static Boolean WarpItem12Enabled;
    public static Boolean WarpItem13Enabled;
    public static Boolean WarpItem14Enabled;
    public static Boolean friendsboolean;

    public static Boolean automsgon;
    public static Integer maxsecrets;

    public void onEnable() {

        instance = this;

        loadConfig();
        loadStrings();
        loadCommands();
        loadEvents();

        Metrics metrics = new Metrics(this);

        ConnectMySQL();

        Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");

        Bukkit.getConsoleSender().sendMessage("§7-------------==+==-------------");
        Bukkit.getConsoleSender().sendMessage("§cPlugin version: §e2.5.0");
        Bukkit.getConsoleSender().sendMessage("§cPlugin author: §eShaderApfel (FehlicksAT)");
        Bukkit.getConsoleSender().sendMessage("§cPlugin status: §aaktiviert");
        Bukkit.getConsoleSender().sendMessage("§7-------------==+==-------------");

        if (LocationAPI.getLocation("spawn") != null) {
            Location spawn = LocationAPI.getLocation("spawn");

            spawn.getWorld().setTime(6000);
            spawn.getWorld().setGameRuleValue("doDaylightCircle", "false");
            spawn.getWorld().setGameRuleValue("doMobSpawning", "false");
        }

        methAutoMessengerScheduler.startCountdown();
    }

    public void onDisable() {

        instance = null;

        Bukkit.getConsoleSender().sendMessage("§7-------------==+==-------------");
        Bukkit.getConsoleSender().sendMessage("§cPlugin version: §e2.5.0");
        Bukkit.getConsoleSender().sendMessage("§cPlugin author: §eShaderApfel (FehlicksAT)");
        Bukkit.getConsoleSender().sendMessage("§cPlugin status: §4deaktiviert");
        Bukkit.getConsoleSender().sendMessage("§7-------------==+==-------------");

    }


    public void ConnectMySQL() {
        mysql = new MySQL(sqlhost, sqldatabase, sqluser, sqlpassword);
        mysql.update("CREATE TABLE IF NOT EXISTS Stats(UUID varchar(64), SJOIN int, COINS int);");
    }


    public void loadConfig() {

        getConfig().addDefault("tab.header", "&8(&cServernetzwerk.de&8)");
        getConfig().addDefault("tab.footer", "&eDas ist der Footer!");

        getConfig().addDefault("enable.gadgets", true);
        getConfig().addDefault("enable.profil", true);
        getConfig().addDefault("enable.lobbyswitcher", true);

        getConfig().addDefault("customitem.enable", true);
        getConfig().addDefault("customitem.id", 360);
        getConfig().addDefault("customitem.displayname", "§6CustomItem §8× §7Rechtsklick");
        getConfig().addDefault("customitem.command", "say %player% hat gerade den CustomItem-Command ausgelöst!");

        getConfig().addDefault("itemid.compass", 345);
        getConfig().addDefault("itemid.playerhider", 404);
        getConfig().addDefault("itemid.rankhider", 359);
        getConfig().addDefault("itemid.flymode", 288);
        getConfig().addDefault("itemid.nogadget", 337);


        getConfig().addDefault("lobbyswitcher.server1.enable", true);
        getConfig().addDefault("lobbyswitcher.server1.name", "Lobby1");
        getConfig().addDefault("lobbyswitcher.server1.this", true);

        getConfig().addDefault("lobbyswitcher.server2.enable", true);
        getConfig().addDefault("lobbyswitcher.server2.name", "Lobby2");
        getConfig().addDefault("lobbyswitcher.server2.this", false);

        getConfig().addDefault("lobbyswitcher.server3.enable", true);
        getConfig().addDefault("lobbyswitcher.server3.name", "Lobby3");
        getConfig().addDefault("lobbyswitcher.server3.this", false);

        getConfig().addDefault("lobbyswitcher.server4.enable", true);
        getConfig().addDefault("lobbyswitcher.server4.name", "Lobby4");
        getConfig().addDefault("lobbyswitcher.server4.this", false);

        getConfig().addDefault("lobbyswitcher.silenthub.enable", true);
        getConfig().addDefault("lobbyswitcher.silenthub.name", "SilentHub");
        getConfig().addDefault("lobbyswitcher.silenthub.this", false);


        getConfig().addDefault("mysql.host", "localhost");
        getConfig().addDefault("mysql.user", "root");
        getConfig().addDefault("mysql.database", "database");
        getConfig().addDefault("mysql.password", "password");
        getConfig().addDefault("servername", "dein-server.de");
        getConfig().addDefault("teamspeak", "ts.dein-server.de");
        getConfig().addDefault("prefix", " &8▌ &6Lobby &8┃ &7");
        getConfig().addDefault("noperms", "&cDu hast nicht die benötigten Rechte!");
        getConfig().addDefault("staffjoinbroadcastmsg", "&7Das Teammitglied §c%name% §7ist dem Server beigetreten!");

        getConfig().addDefault("gm.0.self", "&7Du bist nun im GameMode &6Survival");
        getConfig().addDefault("gm.1.self", "&7Du bist nun im GameMode &6Creative");
        getConfig().addDefault("gm.2.self", "&7Du bist nun im GameMode &6Adventure");
        getConfig().addDefault("gm.3.self", "&7Du bist nun im GameMode &6Spectator");

        getConfig().addDefault("gm.0.other", "&7Der Spieler %player% &7ist nun im GameMode &6Survival");
        getConfig().addDefault("gm.1.other", "&7Der Spieler %player% &7ist nun im GameMode &6Creative");
        getConfig().addDefault("gm.2.other", "&7Der Spieler %player% &7ist nun im GameMode &6Adventure");
        getConfig().addDefault("gm.3.other", "&7Der Spieler %player% &7ist nun im GameMode &6Spectator");

        getConfig().addDefault("gm.unknown", "&6Syntax: &7/gamemode <1/2/3> <Spieler>");

        getConfig().addDefault("msg.ts", "&7Unser TeamSpeak Server: §edeine-ip.de");
        getConfig().addDefault("msg.website", "&7Unsere Website: §edeine-website.de");
        getConfig().addDefault("msg.shop", "&7Unser Shop: §edein-shop.de");
        getConfig().addDefault("msg.youtube", "&7Voraussetzungen zum &5YouTuber&7: §edein-forum.de");

        getConfig().addDefault("gm.incorrect", "&cDieser Spieler konnte nicht gefunden werden!");

        getConfig().addDefault("buildmode.activate.self", "&7Du kannst nun bauen!");
        getConfig().addDefault("buildmode.deactivate.self", "&7Du kannst nun nicht mehr bauen!");

        getConfig().addDefault("buildmode.activate.other", "&7%player% &7kann nun bauen!");
        getConfig().addDefault("buildmode.deactivate.other", "&7%player% &7kann nun nicht mehr bauen!");

        getConfig().addDefault("fly.activate.self", "&7Du kannst nun fliegen!");
        getConfig().addDefault("fly.deactivate.self", "&7Du kannst nun nicht mehr fliegen!");

        getConfig().addDefault("fly.activate.other", "&7%player% &7kann nun fliegen!");
        getConfig().addDefault("fly.deactivate.other", "&7%player% &7kann nun nicht mehr fliegen!");

        getConfig().addDefault("warp.success", "&7Du bist nun bei &c%warp%");
        getConfig().addDefault("warp.failed", "&cDieser Warp existiert nicht!");
        getConfig().addDefault("warp.unknown", "&6Syntax: &7/warp <Name>");

        getConfig().addDefault("spawn.success", "&7Du wurdest zum Spawn teleportiert!");
        getConfig().addDefault("spawn.failed", "&cDer Spawn wurde noch nicht gesetzt!");

        getConfig().addDefault("player.hide.all", "&7Dir werden nun alle Spieler angezeigt");
        getConfig().addDefault("player.hide.vip", "&7Dir werden nun alle VIP Spieler angezeigt");
        getConfig().addDefault("player.hide.no", "&7Dir werden nun keine Spieler angezeigt");

        getConfig().addDefault("weather.sun", "&7Das Wetter wurde zu sonnig umgestellt");
        getConfig().addDefault("weather.rain", "&7Das Wetter wurde zu regen umgestellt");

        getConfig().addDefault("time.day", "&7Die Zeit wurde zu Tag gesetzt");
        getConfig().addDefault("time.night", "&7Die Zeit wurde zu Nacht gesetzt");

        getConfig().addDefault("weather.unknown", "&6Syntax: &7/weather <sun/rain>");
        getConfig().addDefault("time.unknown", "&6Syntax: &7/time <day/night>");

        getConfig().addDefault("nick.an", "&7Dein NickName wurde §aaktiviert");
        getConfig().addDefault("nick.aus", "&7Dein NickName wurde §cdeaktiviert");
        getConfig().addDefault("nick.unknown", "&6Syntax: &7/nick <an/aus>");

        getConfig().addDefault("togglerang.an", "&7Du wirst nun als &8Spieler &7angezeigt!");
        getConfig().addDefault("togglerang.aus", "&7Du wirst nun nicht mehr als &8Spieler &7angezeigt!");

        getConfig().addDefault("setgroup.set", "&7Der Rang von &6%player% &7wurde auf &e%rank% &7gesetzt");
        getConfig().addDefault("setgroup.unknown", "&6Syntax: &7/setgroup <Spieler> <Rang>");
        getConfig().addDefault("setgroup.kickmsg", "&7Dein Neuer Rang: &e%rank%");

        getConfig().addDefault("tp.self", "&7Du wurdest zu %target% &7teleportiert");
        getConfig().addDefault("tp.other", "&7Der Spieler %player% &7wurde zu %target% &7teleportiert");
        getConfig().addDefault("tp.unknown", "§6Syntax: &7/tp <Spieler> <Spieler>");

        getConfig().addDefault("gadget.gadget", "&7Du hast das Gadget &e%gadget% &7ausgewählt");

        getConfig().addDefault("automsg.toggle", true);
        getConfig().addDefault("automsg.1", "&eAutomessage 1");
        getConfig().addDefault("automsg.2", "&eAutomessage 2");
        getConfig().addDefault("automsg.3", "&eAutomessage 3");
        getConfig().addDefault("automsg.4", "&eAutomessage 4");

        getConfig().addDefault("compass.item1.id", 131);
        getConfig().addDefault("compass.item1.name", "&6Warp1");
        getConfig().addDefault("compass.item1.warp", "Warp1");
        getConfig().addDefault("compass.item1.enabled", false);
        getConfig().addDefault("compass.item2.id", 131);
        getConfig().addDefault("compass.item2.name", "&6Warp2");
        getConfig().addDefault("compass.item2.warp", "Warp2");
        getConfig().addDefault("compass.item2.enabled", false);
        getConfig().addDefault("compass.item3.id", 131);
        getConfig().addDefault("compass.item3.name", "&6Warp3");
        getConfig().addDefault("compass.item3.warp", "Warp3");
        getConfig().addDefault("compass.item3.enabled", false);
        getConfig().addDefault("compass.item4.id", 131);
        getConfig().addDefault("compass.item4.name", "&6Warp4");
        getConfig().addDefault("compass.item4.warp", "Warp4");
        getConfig().addDefault("compass.item4.enabled", false);
        getConfig().addDefault("compass.item5.id", 131);
        getConfig().addDefault("compass.item5.name", "&6Warp5");
        getConfig().addDefault("compass.item5.warp", "Warp5");
        getConfig().addDefault("compass.item5.enabled", false);
        getConfig().addDefault("compass.item6.id", 131);
        getConfig().addDefault("compass.item6.name", "&6Warp6");
        getConfig().addDefault("compass.item6.warp", "Warp6");
        getConfig().addDefault("compass.item6.enabled", false);
        getConfig().addDefault("compass.item7.id", 131);
        getConfig().addDefault("compass.item7.name", "&6Warp7");
        getConfig().addDefault("compass.item7.warp", "Warp7");
        getConfig().addDefault("compass.item7.enabled", false);
        getConfig().addDefault("compass.item8.id", 131);
        getConfig().addDefault("compass.item8.name", "&6Warp8");
        getConfig().addDefault("compass.item8.warp", "Warp8");
        getConfig().addDefault("compass.item8.enabled", false);
        getConfig().addDefault("compass.item9.id", 131);
        getConfig().addDefault("compass.item9.name", "&6Warp9");
        getConfig().addDefault("compass.item9.warp", "Warp9");
        getConfig().addDefault("compass.item9.enabled", false);
        getConfig().addDefault("compass.item10.id", 131);
        getConfig().addDefault("compass.item10.name", "&6Warp10");
        getConfig().addDefault("compass.item10.warp", "Warp10");
        getConfig().addDefault("compass.item10.enabled", false);
        getConfig().addDefault("compass.item11.id", 131);
        getConfig().addDefault("compass.item11.name", "&6Warp11");
        getConfig().addDefault("compass.item11.warp", "Warp11");
        getConfig().addDefault("compass.item11.enabled", false);
        getConfig().addDefault("compass.item12.id", 131);
        getConfig().addDefault("compass.item12.name", "&6Warp12");
        getConfig().addDefault("compass.item12.warp", "Warp12");
        getConfig().addDefault("compass.item12.enabled", false);
        getConfig().addDefault("compass.item13.id", 131);
        getConfig().addDefault("compass.item13.name", "&6Warp13");
        getConfig().addDefault("compass.item13.warp", "Warp13");
        getConfig().addDefault("compass.item13.enabled", false);
        getConfig().addDefault("compass.item14.id", 131);
        getConfig().addDefault("compass.item14.name", "&6Warp14");
        getConfig().addDefault("compass.item14.warp", "Warp14");
        getConfig().addDefault("compass.item14.enabled", false);

        getConfig().addDefault("skull.1.name", "&cKopf 1");
        getConfig().addDefault("skull.1.player", "Serverleiter");
        getConfig().addDefault("skull.2.name", "&cKopf 2");
        getConfig().addDefault("skull.2.player", "Serverleiter");
        getConfig().addDefault("skull.3.name", "&cKopf 3");
        getConfig().addDefault("skull.3.player", "Serverleiter");
        getConfig().addDefault("skull.4.name", "&cKopf 4");
        getConfig().addDefault("skull.4.player", "Serverleiter");
        getConfig().addDefault("skull.5.name", "&cKopf 5");
        getConfig().addDefault("skull.5.player", "Serverleiter");
        getConfig().addDefault("skull.6.name", "&cKopf 6");
        getConfig().addDefault("skull.6.player", "Serverleiter");
        getConfig().addDefault("skull.7.name", "&cKopf 7");
        getConfig().addDefault("skull.7.player", "Serverleiter");

        getConfig().addDefault("skull.8.name", "&5GommeHD");
        getConfig().addDefault("skull.8.player", "GommeHD");
        getConfig().addDefault("skull.9.name", "&5Paluten");
        getConfig().addDefault("skull.9.player", "Paluten");
        getConfig().addDefault("skull.10.name", "&5rewinside");
        getConfig().addDefault("skull.10.player", "rewinside");
        getConfig().addDefault("skull.11.name", "&5Alphastein");
        getConfig().addDefault("skull.11.player", "Alphastein");
        getConfig().addDefault("skull.12.name", "&5AviveHD");
        getConfig().addDefault("skull.12.player", "AviveHD");
        getConfig().addDefault("skull.13.name", "&5Fazon");
        getConfig().addDefault("skull.13.player", "Fazon");
        getConfig().addDefault("skull.14.name", "&5ungespielt");
        getConfig().addDefault("skull.14.player", "ungespielt");

        getConfig().addDefault("skull.15.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.15.player", "MHF_Question");
        getConfig().addDefault("skull.16.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.16.player", "MHF_Question");
        getConfig().addDefault("skull.17.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.17.player", "MHF_Question");
        getConfig().addDefault("skull.18.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.18.player", "MHF_Question");
        getConfig().addDefault("skull.19.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.19.player", "MHF_Question");
        getConfig().addDefault("skull.20.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.20.player", "MHF_Question");
        getConfig().addDefault("skull.21.name", "&8[&3SOON&8]");
        getConfig().addDefault("skull.21.player", "MHF_Question");

        getConfig().addDefault("rank.admin.tab", "&4A");
        getConfig().addDefault("rank.admin.chat", "&4Admin");
        getConfig().addDefault("rank.dev.tab", "&bD");
        getConfig().addDefault("rank.dev.chat", "&bDev");
        getConfig().addDefault("rank.srmod.tab", "&cSM");
        getConfig().addDefault("rank.srmod.chat", "&cSrMod");
        getConfig().addDefault("rank.mod.tab", "&cM");
        getConfig().addDefault("rank.mod.chat", "&cMod");
        getConfig().addDefault("rank.supporter.tab", "&aS");
        getConfig().addDefault("rank.supporter.chat", "&aSupport");
        getConfig().addDefault("rank.builder.tab", "&9B");
        getConfig().addDefault("rank.builder.chat", "&9BauTeam");
        getConfig().addDefault("rank.youtuber.tab", "&5YT");
        getConfig().addDefault("rank.youtuber.chat", "&5YouTube");
        getConfig().addDefault("rank.miniyoutuber.tab", "&5MYT");
        getConfig().addDefault("rank.miniyoutuber.chat", "&5MiniYouTube");
        getConfig().addDefault("rank.ultimate.tab", "&bULTIMATE");
        getConfig().addDefault("rank.ultimate.chat", "&bULTIMATE");
        getConfig().addDefault("rank.elite.tab", "&6ELITE");
        getConfig().addDefault("rank.elite.chat", "&6ELITE");
        getConfig().addDefault("rank.plus.tab", "&3PLUS");
        getConfig().addDefault("rank.plus.chat", "&3PLUS");
        getConfig().addDefault("rank.spieler.tab", "&eS");
        getConfig().addDefault("rank.spieler.chat", "&eSpieler");
        getConfig().addDefault("friends.enable", true);
        getConfig().addDefault("friends.command", "friendsgui");

        getConfig().addDefault("help.1", "&8&m-------&7[&6Hilfe&7]&8&m-------");
        getConfig().addDefault("help.2", "&3&lCommands:");
        getConfig().addDefault("help.3", "&c/help &7- &eZeige diese Hilfeseite");
        getConfig().addDefault("help.4", "&c/friends &7- &eZeige deine Freunde an");
        getConfig().addDefault("help.5", "&c/ts &7- &eZeige die TS³ IP an");
        getConfig().addDefault("help.6", "&c/shop &7- &eZeige den Shop an");
        getConfig().addDefault("help.7", "&c/warp <Warp> &7- &eTeleportiere dich zu einem Spielmodus");
        getConfig().addDefault("help.8", "&8&m----------------------");

        getConfig().addDefault("scoreboard.title", "&6dein-server.de");
        getConfig().addDefault("scoreboard.1", "&0");
        getConfig().addDefault("scoreboard.2", "&7Teamspeak-IP&8:");
        getConfig().addDefault("scoreboard.3", "&ets.dein-server.de");
        getConfig().addDefault("scoreboard.4", "&1");
        getConfig().addDefault("scoreboard.5", "&7Rang&8:");
        getConfig().addDefault("scoreboard.6", "%rank%");
        getConfig().addDefault("scoreboard.7", "&2");
        getConfig().addDefault("scoreboard.8", "&7Coins&8:");
        getConfig().addDefault("scoreboard.9", "&e%coins%");
        getConfig().addDefault("scoreboard.10", "&3");

        getConfig().addDefault("joinMotd", "&3Diese Nachricht bekommt jeder Spieler beim joinen!");

        getConfig().options().copyDefaults(true);
        saveConfig();
        reloadConfig();
    }

    public void loadStrings() {


        Server1Activated = getConfig().getBoolean("lobbyswitcher.server1.enable");
        Server2Activated = getConfig().getBoolean("lobbyswitcher.server2.enable");
        Server3Activated = getConfig().getBoolean("lobbyswitcher.server3.enable");
        Server4Activated = getConfig().getBoolean("lobbyswitcher.server4.enable");
        SilentHubActivated = getConfig().getBoolean("lobbyswitcher.silenthub.enable");

        customItemEnabled = getConfig().getBoolean("customitem.enable");
        customItemId = getConfig().getInt("customitem.id");
        customItemDisplayName = getConfig().getString("customitem.displayname");
        customItemCmd = getConfig().getString("customitem.command");

        compassid = getConfig().getInt("itemid.compass");
        playerhiderid = getConfig().getInt("itemid.playerhider");
        rankhiderid = getConfig().getInt("itemid.rankhider");
        nogadgetid = getConfig().getInt("itemid.nogadget");
        flymodeid = getConfig().getInt("itemid.flymode");

        IsServer1 = getConfig().getBoolean("lobbyswitcher.server1.this");
        IsServer2 = getConfig().getBoolean("lobbyswitcher.server2.this");
        IsServer3 = getConfig().getBoolean("lobbyswitcher.server3.this");
        IsServer4 = getConfig().getBoolean("lobbyswitcher.server4.this");
        IsSilentHub = getConfig().getBoolean("lobbyswitcher.silenthub.this");

        Server1Name = getConfig().getString("lobbyswitcher.server1.name");
        Server2Name = getConfig().getString("lobbyswitcher.server2.name");
        Server3Name = getConfig().getString("lobbyswitcher.server3.name");
        Server4Name = getConfig().getString("lobbyswitcher.server4.name");
        SilentHubName = getConfig().getString("lobbyswitcher.silenthub.name");


        gadgetsEnabled = getConfig().getBoolean("enable.gadgets");
        profilEnabled = getConfig().getBoolean("enable.profil");
        lobbyswitcherEnabled = getConfig().getBoolean("enable.lobbyswitcher");

        tabheader = getConfig().getString("tab.header").replaceAll("&", "§");
        tabfooter = getConfig().getString("tab.footer").replaceAll("&", "§");

        joinMotd = getConfig().getString("joinMotd").replaceAll("&", "§");

        sqlhost = getConfig().getString("mysql.host");
        sqldatabase = getConfig().getString("mysql.database");
        sqluser = getConfig().getString("mysql.user");
        sqlpassword = getConfig().getString("mysql.password");


        staffJoinBroadcast = getConfig().getString("staffjoinbroadcastmsg").replaceAll("&", "§");

        servername = getConfig().getString("servername").replaceAll("&", "§");
        teamspeakip = getConfig().getString("teamspeak").replaceAll("&", "§");

        prefix = getConfig().getString("prefix").replaceAll("&", "§");
        noperms = prefix + getConfig().getString("noperms").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        gm0msg = prefix + getConfig().getString("gm.0.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm1msg = prefix + getConfig().getString("gm.1.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm2msg = prefix + getConfig().getString("gm.2.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm3msg = prefix + getConfig().getString("gm.3.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm0msgP = prefix + getConfig().getString("gm.0.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm1msgP = prefix + getConfig().getString("gm.1.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm2msgP = prefix + getConfig().getString("gm.2.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        gm3msgP = prefix + getConfig().getString("gm.3.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        unknowngm = prefix + getConfig().getString("gm.unknown").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        playernotfound = prefix
                + getConfig().getString("gm.incorrect").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        tsmsg = prefix + instance.getConfig().getString("msg.ts").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        youtubemsg = prefix + instance.getConfig().getString("msg.youtube").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        websitemsg = prefix
                + instance.getConfig().getString("msg.website").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        shopmsg = prefix
                + instance.getConfig().getString("msg.shop").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        buildmodeoff = prefix + getConfig().getString("buildmode.deactivate.self").replaceAll("&", "§")
                .replaceAll("%prefix%", prefix);
        buildmodeon = prefix
                + getConfig().getString("buildmode.activate.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        buildmodeoffother = prefix + getConfig().getString("buildmode.deactivate.other").replaceAll("&", "§")
                .replaceAll("%prefix%", prefix);
        buildmodeonother = prefix
                + getConfig().getString("buildmode.activate.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        flymodeoff = prefix
                + getConfig().getString("fly.deactivate.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        flymodeon = prefix
                + getConfig().getString("fly.activate.self").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        flymodeoffother = prefix
                + getConfig().getString("fly.activate.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        flymodeonother = prefix
                + getConfig().getString("fly.activate.other").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        warpfailed = prefix + getConfig().getString("warp.failed").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        unknownwarp = prefix
                + getConfig().getString("warp.unknown").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        warpsuccessful = prefix
                + getConfig().getString("warp.success").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        automsgon = getConfig().getBoolean("automsg.toggle");
        automsg1 = getConfig().getString("automsg.1").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        automsg2 = getConfig().getString("automsg.2").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        automsg3 = getConfig().getString("automsg.3").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        automsg4 = getConfig().getString("automsg.4").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        spawnsuccessful = prefix
                + getConfig().getString("spawn.success").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        spawnfailed = prefix
                + getConfig().getString("spawn.failed").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        allplayer = prefix
                + getConfig().getString("player.hide.all").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        vipplayer = prefix
                + getConfig().getString("player.hide.vip").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        noplayer = prefix + getConfig().getString("player.hide.no").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        weathersun = prefix + getConfig().getString("weather.sun").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        weatherrain = prefix
                + getConfig().getString("weather.rain").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        timeday = prefix + getConfig().getString("time.day").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        timenight = prefix + getConfig().getString("time.night").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        unknownweather = prefix
                + getConfig().getString("weather.unknown").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        unknowntime = prefix
                + getConfig().getString("time.unknown").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        nickan = prefix + getConfig().getString("nick.an").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        nickaus = prefix + getConfig().getString("nick.aus").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        unknownnick = prefix
                + getConfig().getString("nick.unknown").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        silentlobbyan = prefix
                + getConfig().getString("togglerang.an").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        silentlobbyaus = prefix
                + getConfig().getString("togglerang.aus").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        setgroup = prefix + getConfig().getString("setgroup.set").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        unknownsetgroup = prefix
                + getConfig().getString("setgroup.unknown").replaceAll("&", "§").replaceAll("%prefix%", prefix);
        setgroupkickmsg = prefix
                + getConfig().getString("setgroup.kickmsg").replaceAll("&", "§").replaceAll("%prefix%", prefix);

        tpself = prefix + getConfig().getString("tp.self").replaceAll("&", "§");
        tpother = prefix + getConfig().getString("tp.other").replaceAll("&", "§");
        unknowntp = prefix + getConfig().getString("tp.unknown").replaceAll("&", "§");

        gadget = prefix + getConfig().getString("gadget.gadget").replaceAll("&", "§");

        skullname1 = getConfig().getString("skull.1.name").replaceAll("&", "§");
        skullname2 = getConfig().getString("skull.2.name").replaceAll("&", "§");
        skullname3 = getConfig().getString("skull.3.name").replaceAll("&", "§");
        skullname4 = getConfig().getString("skull.4.name").replaceAll("&", "§");
        skullname5 = getConfig().getString("skull.5.name").replaceAll("&", "§");
        skullname6 = getConfig().getString("skull.6.name").replaceAll("&", "§");
        skullname7 = getConfig().getString("skull.7.name").replaceAll("&", "§");
        skullname8 = getConfig().getString("skull.8.name").replaceAll("&", "§");
        skullname9 = getConfig().getString("skull.9.name").replaceAll("&", "§");
        skullname10 = getConfig().getString("skull.10.name").replaceAll("&", "§");
        skullname11 = getConfig().getString("skull.11.name").replaceAll("&", "§");
        skullname12 = getConfig().getString("skull.12.name").replaceAll("&", "§");
        skullname13 = getConfig().getString("skull.13.name").replaceAll("&", "§");
        skullname14 = getConfig().getString("skull.14.name").replaceAll("&", "§");
        skullname15 = getConfig().getString("skull.15.name").replaceAll("&", "§");
        skullname16 = getConfig().getString("skull.16.name").replaceAll("&", "§");
        skullname17 = getConfig().getString("skull.17.name").replaceAll("&", "§");
        skullname18 = getConfig().getString("skull.18.name").replaceAll("&", "§");
        skullname19 = getConfig().getString("skull.19.name").replaceAll("&", "§");
        skullname20 = getConfig().getString("skull.20.name").replaceAll("&", "§");
        skullname21 = getConfig().getString("skull.21.name").replaceAll("&", "§");

        help1 = getConfig().getString("help.1").replaceAll("&", "§");
        help2 = getConfig().getString("help.2").replaceAll("&", "§");
        help3 = getConfig().getString("help.3").replaceAll("&", "§");
        help4 = getConfig().getString("help.4").replaceAll("&", "§");
        help5 = getConfig().getString("help.5").replaceAll("&", "§");
        help6 = getConfig().getString("help.6").replaceAll("&", "§");
        help7 = getConfig().getString("help.7").replaceAll("&", "§");
        help8 = getConfig().getString("help.8").replaceAll("&", "§");

        skullplayername1 = getConfig().getString("skull.1.player");
        skullplayername2 = getConfig().getString("skull.2.player");
        skullplayername3 = getConfig().getString("skull.3.player");
        skullplayername4 = getConfig().getString("skull.4.player");
        skullplayername5 = getConfig().getString("skull.5.player");
        skullplayername6 = getConfig().getString("skull.6.player");
        skullplayername7 = getConfig().getString("skull.7.player");
        skullplayername8 = getConfig().getString("skull.8.player");
        skullplayername9 = getConfig().getString("skull.9.player");
        skullplayername10 = getConfig().getString("skull.10.player");
        skullplayername11 = getConfig().getString("skull.11.player");
        skullplayername12 = getConfig().getString("skull.12.player");
        skullplayername13 = getConfig().getString("skull.13.player");
        skullplayername14 = getConfig().getString("skull.14.player");
        skullplayername15 = getConfig().getString("skull.15.player");
        skullplayername16 = getConfig().getString("skull.16.player");
        skullplayername17 = getConfig().getString("skull.17.player");
        skullplayername18 = getConfig().getString("skull.18.player");
        skullplayername19 = getConfig().getString("skull.19.player");
        skullplayername20 = getConfig().getString("skull.20.player");
        skullplayername21 = getConfig().getString("skull.21.player");

        WarpItem1 = Material.getMaterial(getConfig().getInt("compass.item1.id"));
        WarpItem2 = Material.getMaterial(getConfig().getInt("compass.item2.id"));
        WarpItem3 = Material.getMaterial(getConfig().getInt("compass.item3.id"));
        WarpItem4 = Material.getMaterial(getConfig().getInt("compass.item4.id"));
        WarpItem5 = Material.getMaterial(getConfig().getInt("compass.item5.id"));
        WarpItem6 = Material.getMaterial(getConfig().getInt("compass.item6.id"));
        WarpItem7 = Material.getMaterial(getConfig().getInt("compass.item7.id"));
        WarpItem8 = Material.getMaterial(getConfig().getInt("compass.item8.id"));
        WarpItem9 = Material.getMaterial(getConfig().getInt("compass.item9.id"));
        WarpItem10 = Material.getMaterial(getConfig().getInt("compass.item10.id"));
        WarpItem11 = Material.getMaterial(getConfig().getInt("compass.item11.id"));
        WarpItem12 = Material.getMaterial(getConfig().getInt("compass.item12.id"));
        WarpItem13 = Material.getMaterial(getConfig().getInt("compass.item13.id"));
        WarpItem14 = Material.getMaterial(getConfig().getInt("compass.item14.id"));

        WarpItem1Name = getConfig().getString("compass.item1.name").replaceAll("&", "§");
        WarpItem2Name = getConfig().getString("compass.item2.name").replaceAll("&", "§");
        WarpItem3Name = getConfig().getString("compass.item3.name").replaceAll("&", "§");
        WarpItem4Name = getConfig().getString("compass.item4.name").replaceAll("&", "§");
        WarpItem5Name = getConfig().getString("compass.item5.name").replaceAll("&", "§");
        WarpItem6Name = getConfig().getString("compass.item6.name").replaceAll("&", "§");
        WarpItem7Name = getConfig().getString("compass.item7.name").replaceAll("&", "§");
        WarpItem8Name = getConfig().getString("compass.item8.name").replaceAll("&", "§");
        WarpItem9Name = getConfig().getString("compass.item9.name").replaceAll("&", "§");
        WarpItem10Name = getConfig().getString("compass.item10.name").replaceAll("&", "§");
        WarpItem11Name = getConfig().getString("compass.item11.name").replaceAll("&", "§");
        WarpItem12Name = getConfig().getString("compass.item12.name").replaceAll("&", "§");
        WarpItem13Name = getConfig().getString("compass.item13.name").replaceAll("&", "§");
        WarpItem14Name = getConfig().getString("compass.item14.name").replaceAll("&", "§");

        WarpItem1WarpName = getConfig().getString("compass.item1.warp");
        WarpItem2WarpName = getConfig().getString("compass.item2.warp");
        WarpItem3WarpName = getConfig().getString("compass.item3.warp");
        WarpItem4WarpName = getConfig().getString("compass.item4.warp");
        WarpItem5WarpName = getConfig().getString("compass.item5.warp");
        WarpItem6WarpName = getConfig().getString("compass.item6.warp");
        WarpItem7WarpName = getConfig().getString("compass.item7.warp");
        WarpItem8WarpName = getConfig().getString("compass.item8.warp");
        WarpItem9WarpName = getConfig().getString("compass.item9.warp");
        WarpItem10WarpName = getConfig().getString("compass.item10.warp");
        WarpItem11WarpName = getConfig().getString("compass.item11.warp");
        WarpItem12WarpName = getConfig().getString("compass.item12.warp");
        WarpItem13WarpName = getConfig().getString("compass.item13.warp");
        WarpItem14WarpName = getConfig().getString("compass.item14.warp");

        friendscommand = getConfig().getString("friends.command");
        friendsboolean = getConfig().getBoolean("friends.enable");

        WarpItem1Enabled = getConfig().getBoolean("compass.item1.enabled");
        WarpItem2Enabled = getConfig().getBoolean("compass.item2.enabled");
        WarpItem3Enabled = getConfig().getBoolean("compass.item3.enabled");
        WarpItem4Enabled = getConfig().getBoolean("compass.item4.enabled");
        WarpItem5Enabled = getConfig().getBoolean("compass.item5.enabled");
        WarpItem6Enabled = getConfig().getBoolean("compass.item6.enabled");
        WarpItem7Enabled = getConfig().getBoolean("compass.item7.enabled");
        WarpItem8Enabled = getConfig().getBoolean("compass.item8.enabled");
        WarpItem9Enabled = getConfig().getBoolean("compass.item9.enabled");
        WarpItem10Enabled = getConfig().getBoolean("compass.item10.enabled");
        WarpItem11Enabled = getConfig().getBoolean("compass.item11.enabled");
        WarpItem12Enabled = getConfig().getBoolean("compass.item12.enabled");
        WarpItem13Enabled = getConfig().getBoolean("compass.item13.enabled");
        WarpItem14Enabled = getConfig().getBoolean("compass.item14.enabled");
        maxsecrets = getConfig().getInt("secrets.max");

        rankadmintab = getConfig().getString("rank.admin.tab").replaceAll("&", "§");
        rankadmin = getConfig().getString("rank.admin.chat").replaceAll("&", "§");
        rankdevtab = getConfig().getString("rank.dev.tab").replaceAll("&", "§");
        rankdev = getConfig().getString("rank.dev.chat").replaceAll("&", "§");
        ranksrmodtab = getConfig().getString("rank.srmod.tab").replaceAll("&", "§");
        ranksrmod = getConfig().getString("rank.srmod.chat").replaceAll("&", "§");
        rankmodtab = getConfig().getString("rank.mod.tab").replaceAll("&", "§");
        rankmod = getConfig().getString("rank.mod.chat").replaceAll("&", "§");
        ranksupportertab = getConfig().getString("rank.supporter.tab").replaceAll("&", "§");
        ranksupporter = getConfig().getString("rank.supporter.chat").replaceAll("&", "§");
        rankbuildertab = getConfig().getString("rank.builder.tab").replaceAll("&", "§");
        rankbuilder = getConfig().getString("rank.builder.chat").replaceAll("&", "§");
        rankyoutubertab = getConfig().getString("rank.youtuber.tab").replaceAll("&", "§");
        rankyoutuber = getConfig().getString("rank.youtuber.chat").replaceAll("&", "§");
        rankminiyoutubertab = getConfig().getString("rank.miniyoutuber.tab").replaceAll("&", "§");
        rankminiyoutuber = getConfig().getString("rank.miniyoutuber.chat").replaceAll("&", "§");
        rankultimatetab = getConfig().getString("rank.ultimate.tab").replaceAll("&", "§");
        rankultimate = getConfig().getString("rank.ultimate.chat").replaceAll("&", "§");
        rankelitetab = getConfig().getString("rank.elite.tab").replaceAll("&", "§");
        rankelite = getConfig().getString("rank.elite.chat").replaceAll("&", "§");
        rankplustab = getConfig().getString("rank.plus.tab").replaceAll("&", "§");
        rankplus = getConfig().getString("rank.plus.chat").replaceAll("&", "§");
        rankspielertab = getConfig().getString("rank.spieler.tab").replaceAll("&", "§");
        rankspieler = getConfig().getString("rank.spieler.chat").replaceAll("&", "§");

        sbtitle = getConfig().getString("scoreboard.title").replaceAll("&", "§");
        sb1 = getConfig().getString("scoreboard.1").replaceAll("&", "§");
        sb2 = getConfig().getString("scoreboard.2").replaceAll("&", "§");
        sb3 = getConfig().getString("scoreboard.3").replaceAll("&", "§");
        sb4 = getConfig().getString("scoreboard.4").replaceAll("&", "§");
        sb5 = getConfig().getString("scoreboard.5").replaceAll("&", "§");
        sb6 = getConfig().getString("scoreboard.6").replaceAll("&", "§");
        sb7 = getConfig().getString("scoreboard.7").replaceAll("&", "§");
        sb8 = getConfig().getString("scoreboard.8").replaceAll("&", "§");
        sb9 = getConfig().getString("scoreboard.9").replaceAll("&", "§");
        sb10 = getConfig().getString("scoreboard.10").replaceAll("&", "§");
    }

    public void loadCommands() {

        getCommand("ts").setExecutor(new CMD_ads());
        getCommand("website").setExecutor(new CMD_ads());
        getCommand("shop").setExecutor(new CMD_ads());
        getCommand("youtube").setExecutor(new CMD_ads());
        getCommand("gamemode").setExecutor(new CMD_gamemode());
        getCommand("buildmode").setExecutor(new CMD_buildmode());
        getCommand("setwarp").setExecutor(new CMD_setwarp());
        getCommand("warp").setExecutor(new CMD_warp());
        getCommand("setspawn").setExecutor(new CMD_setspawn());
        getCommand("spawn").setExecutor(new CMD_spawn());
        getCommand("fly").setExecutor(new CMD_fly());
        getCommand("time").setExecutor(new CMD_time());
        getCommand("weather").setExecutor(new CMD_weather());
        getCommand("setgroup").setExecutor(new CMD_setgroup());
        getCommand("tp").setExecutor(new CMD_tp());
        getCommand("secret").setExecutor(new CMD_secret());
        getCommand("help").setExecutor(new CMD_help());
        getCommand("silentjoin").setExecutor(new CMD_silentjoin());
        getCommand("cc").setExecutor(new CMD_cc());
        getCommand("coins").setExecutor(new CMD_coins());
    }

    public void loadEvents() {

        Bukkit.getPluginManager().registerEvents(new Build(), this);
        Bukkit.getPluginManager().registerEvents(new Join(), this);
        Bukkit.getPluginManager().registerEvents(new QuitKick(), this);
        Bukkit.getPluginManager().registerEvents(new InvClick(), this);
        Bukkit.getPluginManager().registerEvents(new InvClickKleiderschrank(), this);
        Bukkit.getPluginManager().registerEvents(new DropPickup(), this);
        Bukkit.getPluginManager().registerEvents(new Damage(), this);
        Bukkit.getPluginManager().registerEvents(new FoodLevel(), this);
        Bukkit.getPluginManager().registerEvents(new compass(), this);
        Bukkit.getPluginManager().registerEvents(new playerhider(), this);
        Bukkit.getPluginManager().registerEvents(new flymode(), this);
        Bukkit.getPluginManager().registerEvents(new InvClose(), this);
        Bukkit.getPluginManager().registerEvents(new nick(), this);
        Bukkit.getPluginManager().registerEvents(new customitem(), this);
        Bukkit.getPluginManager().registerEvents(new profil(), this);
        Bukkit.getPluginManager().registerEvents(new zertrampeln(), this);
        Bukkit.getPluginManager().registerEvents(new togglerank(), this);
        Bukkit.getPluginManager().registerEvents(new gadget(), this);
        Bukkit.getPluginManager().registerEvents(new Chat(), this);
        Bukkit.getPluginManager().registerEvents(new jumppads(), this);
        Bukkit.getPluginManager().registerEvents(new Weather(), this);
        Bukkit.getPluginManager().registerEvents(new Move(), this);
        Bukkit.getPluginManager().registerEvents(new Preprocess(), this);
    }

    public static Main getInstance() {

        return instance;

    }

}
