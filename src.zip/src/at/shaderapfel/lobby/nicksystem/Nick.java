package at.shaderapfel.lobby.nicksystem;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public class Nick {

	public static void randomNick(Player player) {
		player.setDisplayName("GleichMitte");
	}
	
	

}