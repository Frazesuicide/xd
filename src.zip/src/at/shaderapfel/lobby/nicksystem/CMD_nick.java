package at.shaderapfel.lobby.nicksystem;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_nick implements CommandExecutor {
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		
		if(cmd.getName().equalsIgnoreCase("nick")) {
			if(sender instanceof Player) {
				if(p.hasPermission("lobby.nick")) {
					if(args.length == 0) {
						p.sendMessage(Main.unknownnick);
						return true;
					} else {
						if(args[0].equalsIgnoreCase("an")) {
							p.sendMessage(Main.nickan);
							
						} else if(args[0].equalsIgnoreCase("aus")) {
							p.sendMessage(Main.nickaus);
							
						} else {
							p.sendMessage(Main.unknownnick);
							return true;
						}
					}
				}
			}
		}
		
		return false;
	}

}
