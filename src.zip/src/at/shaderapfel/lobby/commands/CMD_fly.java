package at.shaderapfel.lobby.commands;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_fly implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player player = (Player) sender;

		if (player.hasPermission("lobby.fly")) {
			if (args.length == 0) {
				if (!Main.fly.contains(player)) {
					Main.fly.add(player);
					player.sendMessage(Main.flymodeon);
					player.setAllowFlight(true);
					player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
				} else if (Main.fly.contains(player)) {
					Main.fly.remove(player);
					player.setAllowFlight(false);
					player.sendMessage(Main.flymodeoff);
					player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
				}
			} else if (args.length == 1) {
				if (Bukkit.getPlayer(args[1]) != null) {
					Player target = Bukkit.getPlayer(args[1]);

					if (!Main.fly.contains(target)) {
						Main.fly.add(target);
						target.setAllowFlight(true);
						player.sendMessage(Main.flymodeonother);
						player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
					} else if (Main.fly.contains(target)) {
						Main.fly.remove(target);
						target.setAllowFlight(false);
						player.sendMessage(Main.flymodeoffother);
						player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
					}
				}
			}

		} else {
			player.sendMessage(Main.noperms);

		}
		return true;

	}
}
