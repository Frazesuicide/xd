package at.shaderapfel.lobby.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.LocationAPI;

public class CMD_setwarp implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player player = (Player) sender;

		if (player.hasPermission("lobby.setwarp")) {
			if (args.length == 1) {
				LocationAPI.setLocation(player.getLocation(), "warp." + args[0].toLowerCase());
				player.sendMessage(Main.prefix + "§aDu hast erfolgreich einen Warp gesetzt!");
			} else {
				player.sendMessage(Main.prefix + "§6Syntax: §7/setwarp <Name>");
			}
		} else {
			player.sendMessage(Main.noperms);
		}

		return true;
	}

}
