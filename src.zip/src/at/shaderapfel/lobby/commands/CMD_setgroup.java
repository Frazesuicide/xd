package at.shaderapfel.lobby.commands;


import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_setgroup implements CommandExecutor { 
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		
		if(cmd.getName().equalsIgnoreCase("setgroup")) {
			if(p.hasPermission("lobby.setgroup")) {
				if(args.length == 0) {
					p.sendMessage(Main.unknownsetgroup);
					return true;
				}
				Player target = Bukkit.getPlayer(args[0]);
		        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pex user " + target.getName() + " group set " + args[1]);
		        p.sendMessage(Main.instance.getConfig().getString("setgroup.set").replaceAll("&", "§").replaceAll("%player%", target.getName()).replaceAll("%rank%", args[1]));
		        target.kickPlayer(Main.instance.getConfig().getString("setgroup.kickmsg").replaceAll("&", "§").replaceAll("%rank%", args[1]));
			} else {
				p.sendMessage(Main.noperms);
			}
		}
		
		return false;
	}

}