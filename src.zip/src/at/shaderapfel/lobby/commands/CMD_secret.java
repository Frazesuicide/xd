package at.shaderapfel.lobby.commands;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import at.shaderapfel.lobby.methods.LocationAPI;
import at.shaderapfel.lobby.utils.ItemUtils;

public class CMD_secret implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		if (sender instanceof Player) {
			Player p = (Player) sender;

			if (p.hasPermission("lobby.setsecrets")) {

//				p.getInventory().addItem(ItemUtils.getHead("MHF_Question", "§cSecret Nr. "+LocationAPI.cfg.getInt("secretsset")+1,
//						"§7Setze dieses Secret an eine\n§7beliebige Stelle in der Lobby", 0, 1));
				ItemStack i7 = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
				SkullMeta i7m = (SkullMeta) i7.getItemMeta();
				i7m.setOwner("MHF_Question");
				i7m.setDisplayName("§cSecret §8- §7Bitte 2 Blöcke darunter Schild mit Ganzzahl platzieren!");
				i7.setItemMeta(i7m);
				p.getInventory().addItem(i7);
				p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);
			}

		}

		return false;
	}

}
