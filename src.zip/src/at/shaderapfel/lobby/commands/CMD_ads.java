package at.shaderapfel.lobby.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.Drops;
import at.shaderapfel.lobby.methods.Inventories;

public class CMD_ads implements CommandExecutor {

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player p = (Player) sender;

        if (cmd.getName().equalsIgnoreCase("ts")) {
            p.sendMessage(Main.tsmsg);
        }
        if (cmd.getName().equalsIgnoreCase("wesbite")) {
            p.sendMessage(Main.websitemsg);
        }
        if (cmd.getName().equalsIgnoreCase("shop")) {
            p.sendMessage(Main.shopmsg);
        }
        if (cmd.getName().equalsIgnoreCase("youtube")) {
            p.sendMessage(Main.youtubemsg);
        }


        return true;
    }

}