package at.shaderapfel.lobby.commands;

import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_help implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		sender.sendMessage(Main.help1);
		sender.sendMessage(Main.help2);
		sender.sendMessage(Main.help3);
		sender.sendMessage(Main.help4);
		sender.sendMessage(Main.help5);
		sender.sendMessage(Main.help6);
		sender.sendMessage(Main.help7);
		sender.sendMessage(Main.help8);
		
		if (sender instanceof Player) {
			Player p = (Player) sender;

			p.playSound(p.getLocation(), Sound.ORB_PICKUP, 1, 1);
		}

		return false;
	}

}
