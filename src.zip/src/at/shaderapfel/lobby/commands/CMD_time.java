package at.shaderapfel.lobby.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_time implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		
		if(cmd.getName().equalsIgnoreCase("time")) {
			if(p.hasPermission("lobby.time")) {
				if(args.length == 0) {
					sender.sendMessage(Main.unknowntime);
					return true;
				}
				if(args[0].equalsIgnoreCase("day")) {
					p.sendMessage(Main.timeday);
					p.getWorld().setFullTime(0);
					
				} else if(args[0].equalsIgnoreCase("night")) {
					p.sendMessage(Main.timenight);
					p.getWorld().setFullTime(16000);
					
				} else {
					sender.sendMessage(Main.unknowntime);
					return true;
				}
			} else {
				p.sendMessage(Main.noperms);
				return true;
			}
		}
		
		return false;
	}		

}
