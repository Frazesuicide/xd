package at.shaderapfel.lobby.commands;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.LocationAPI;

public class CMD_warp implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player player = (Player) sender;

		if (args.length == 1) {
			if (LocationAPI.locationExists("warp."+args[0].toLowerCase())) {
				Location loc = LocationAPI.getLocation("warp." + args[0].toLowerCase());

				player.teleport(loc);
				player.sendMessage(Main.warpsuccessful.replaceAll("%warp%", args[0]));
				player.playSound(loc, Sound.FIREWORK_BLAST, 1, 1);

			} else {
				player.sendMessage(Main.warpfailed);
				player.closeInventory();
			}
		} else {
			player.sendMessage(Main.unknownwarp);
		}

		return true;
	}

}
