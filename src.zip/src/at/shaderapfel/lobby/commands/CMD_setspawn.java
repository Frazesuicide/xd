package at.shaderapfel.lobby.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.LocationAPI;

public class CMD_setspawn implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player player = (Player) sender;

		if (player.hasPermission("lobby.setspawn")) {
			if (args.length == 0) {
				LocationAPI.setLocation(player.getLocation(), "spawn");
				player.sendMessage(Main.prefix + "§aDu hast erfolgreich den Spawn gesetzt!");
			} else {
				player.sendMessage(Main.prefix + "§6Syntax: §7/setspawn");
			}
		} else {
			player.sendMessage(Main.noperms);
		}

		return true;
	}

}
