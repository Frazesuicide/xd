package at.shaderapfel.lobby.commands;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.LocationAPI;

public class CMD_spawn implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player player = (Player) sender;

		if (args.length == 0) {
			if (LocationAPI.locationExists("spawn")) {
				Location loc = LocationAPI.getLocation("spawn");

				player.teleport(loc);
				player.sendMessage(Main.spawnsuccessful);
				player.playSound(loc, Sound.FIREWORK_BLAST, 1, 1);

			} else {
				player.sendMessage(Main.spawnfailed);
				player.closeInventory();
			}
		} else {
			player.sendMessage(Main.prefix + "§6Syntax: §7/warp <Name>");
		}

		return true;
	}

}
