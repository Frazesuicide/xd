package at.shaderapfel.lobby.commands;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.utils.SQLApi;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Created by shaderapfel on 18.02.17.
 */
public class CMD_coins implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            Player p = (Player) sender;

            if (args.length == 0) {
                p.sendMessage(Main.prefix + "Du bist im Besitz von §c" + SQLApi.getCoins(p.getUniqueId().toString()) + " §7Coins!");
            } else if (args.length == 1) {
                if (p.hasPermission("coins.other")) {
                    Player target = Bukkit.getPlayer(args[0]);

                    if (target != null) {
                        p.sendMessage(Main.prefix + args[0] + " ist im Besitz von §c" + SQLApi.getCoins(target.getUniqueId().toString()) + " §7Coins!");
                    } else {
                        p.sendMessage(Main.prefix + "§cDieser Spieler wurde nicht gefunden!");
                    }
                }else{
                    p.sendMessage(Main.noperms);
                }
            }else if(args.length == 3){
                if(args[0].equalsIgnoreCase("set")){
                    if(p.hasPermission("coins.set")){
                        if(Bukkit.getPlayer(args[1]) != null){
                            if(isNumeric(args[2])){
                                Player target = Bukkit.getPlayer(args[1]);
                                SQLApi.setCoins(target.getUniqueId().toString(), Integer.parseInt(args[2]));
                                p.sendMessage(Main.prefix+ "Der Spieler §e"+ target.getDisplayName()+ " §7hat nun §e"+args[2]+" §7Coins!");
                            }else{
                                p.sendMessage(Main.prefix+"Du musst eine Zahl angeben!");
                            }
                        }else{
                            p.sendMessage(Main.prefix+"Dieser Spieler existiert nicht!");
                        }
                    }else{
                        p.sendMessage(Main.noperms);
                    }
                }else if(args[0].equalsIgnoreCase("add")){
                    if(p.hasPermission("coins.add")){
                        if(Bukkit.getPlayer(args[1]) != null){
                            if(isNumeric(args[2])){
                                Player target = Bukkit.getPlayer(args[1]);
                                SQLApi.addCoins(target.getUniqueId().toString(), Integer.parseInt(args[2]));
                                p.sendMessage(Main.prefix+ "Der Spieler §e"+ target.getDisplayName()+ " §7hat §e"+args[2]+" §7Coins erhalten!");
                            }else{
                                p.sendMessage(Main.prefix+"Du musst eine Zahl angeben!");
                            }
                        }else{
                            p.sendMessage(Main.prefix+"Dieser Spieler existiert nicht!");
                        }
                    }else{
                        p.sendMessage(Main.noperms);
                    }
                }else if(args[0].equalsIgnoreCase("remove")){
                    if(p.hasPermission("coins.remove")){
                        if(Bukkit.getPlayer(args[1]) != null){
                            if(isNumeric(args[2])){
                                Player target = Bukkit.getPlayer(args[1]);
                                SQLApi.removeCoins(target.getUniqueId().toString(), Integer.parseInt(args[2]));
                                p.sendMessage(Main.prefix+ "Dem Spieler §e"+ target.getDisplayName()+ " §7wurden §e"+args[2]+" §7Coins abgezogen!");
                            }else{
                                p.sendMessage(Main.prefix+"Du musst eine Zahl angeben!");
                            }
                        }else{
                            p.sendMessage(Main.prefix+"Dieser Spieler existiert nicht!");
                        }
                    }else{
                        p.sendMessage(Main.noperms);
                    }
                }else{
                    p.sendMessage(Main.prefix+"Benutzung: /coins set <Spieler> <Anzahl>");
                }
            }else{
                p.sendMessage(Main.prefix+"Benutzung: /coins set <Spieler> <Anzahl>");
            }
        }


        return false;
    }

    public boolean isNumeric(String s) {
        return s.matches("\\d+");
    }
}
