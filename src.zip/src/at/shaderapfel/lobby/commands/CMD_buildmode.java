package at.shaderapfel.lobby.commands;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_buildmode implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        Player player = (Player) sender;

        if (player.hasPermission("lobby.build")) {
            if (args.length == 0) {
                if (!Main.buildmode.contains(player)) {
                    Main.buildmode.add(player);
                    player.sendMessage(Main.buildmodeon);
                    player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
                } else if (Main.buildmode.contains(player)) {
                    Main.buildmode.remove(player);
                    player.sendMessage(Main.buildmodeoff);
                    player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
                }
            } else if (args.length == 1) {
                if (Bukkit.getPlayer(args[1]) != null) {
                    Player target = Bukkit.getPlayer(args[1]);

                    if (!Main.buildmode.contains(target)) {
                        Main.buildmode.add(target);
                        player.sendMessage(Main.buildmodeonother);
                        player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
                    } else if (Main.buildmode.contains(target)) {
                        Main.buildmode.remove(target);
                        player.sendMessage(Main.buildmodeoffother);
                        player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);
                    }
                }
            } else {
                player.sendMessage(Main.noperms);
            }

        }
        return true;

    }
}
