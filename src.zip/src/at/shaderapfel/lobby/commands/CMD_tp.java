package at.shaderapfel.lobby.commands;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_tp implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;

		if (player.hasPermission("lobby.tp")) {
			if (args.length == 1) {
				String targetname = args[0];
				Player target = Bukkit.getPlayer(targetname);
				if (Bukkit.getPlayer(targetname) != null) {
					player.teleport(target.getLocation());
					player.sendMessage(Main.tpself.replaceAll("%target%",
							target.getDisplayName().replaceAll("%prefix%", Main.prefix).replaceAll("&", "§")));
					player.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1, 1);
				} else {
					player.sendMessage(Main.playernotfound.replaceAll("&", "§"));
					player.playSound(player.getLocation(), Sound.ANVIL_BREAK, 1, 1);
				}
			} else if (args.length == 2) {
				String teleportedname = args[0];
				Player teleported = Bukkit.getPlayer(teleportedname);
				String targetname = args[1];
				Player target = Bukkit.getPlayer(targetname);

				if (Bukkit.getPlayer(targetname) != null || Bukkit.getPlayer(teleportedname) != null) {
					teleported.teleport(target.getLocation());
					player.sendMessage(Main.tpother.replaceAll("%player%",
							teleported.getDisplayName().replaceAll("%target%", target.getDisplayName())
									.replaceAll("%prefix%", Main.prefix).replaceAll("&", "§")));
					teleported.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1, 1);
					player.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1, 1);
				} else {
					player.sendMessage(Main.playernotfound.replaceAll("&", "§"));
					player.playSound(player.getLocation(), Sound.ANVIL_BREAK, 1, 1);
				}
			} else {
				player.sendMessage(Main.unknowntp);
			}
		} else {
			player.sendMessage(Main.noperms);
		}

		return true;
	}

}
