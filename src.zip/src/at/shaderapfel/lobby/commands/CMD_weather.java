package at.shaderapfel.lobby.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class CMD_weather implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		
		if(cmd.getName().equalsIgnoreCase("weather")) {
			if(p.hasPermission("lobby.weather")) {
				if(args.length == 0) {
					sender.sendMessage(Main.unknownweather);
					return true;
				}
				if(args[0].equalsIgnoreCase("sun")) {
					p.sendMessage(Main.weathersun);
					p.getWorld().setStorm(false);
					
				} else if(args[0].equalsIgnoreCase("rain")) {
					p.sendMessage(Main.weatherrain);
					p.getWorld().setStorm(true);
					
				} else {
					sender.sendMessage(Main.unknownweather);
					return true;
				}
			} else {
				p.sendMessage(Main.noperms);
				return true;
			}
		}
		
		return false;
	}		

}
