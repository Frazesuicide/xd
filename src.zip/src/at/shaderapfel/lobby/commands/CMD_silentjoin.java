package at.shaderapfel.lobby.commands;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.utils.SQLApi;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Created by shaderapfel on 18.02.17.
 */
public class CMD_silentjoin implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if(sender instanceof Player){
            Player p = (Player) sender;

            if(p.hasPermission("lobby.joinBroadcast")){
                if(args.length == 1){
                    if (args[0].equalsIgnoreCase("on")){
                        SQLApi.setSilentJoin(p.getUniqueId().toString(), true);
                        p.sendMessage(Main.prefix+"Ab sofort wird keine Broadcast-Message mehr beim Join gesendet!");
                    }else if (args[0].equalsIgnoreCase("off")){
                        SQLApi.setSilentJoin(p.getUniqueId().toString(), false);
                        p.sendMessage(Main.prefix+"Ab sofort wird eine Broadcast-Message beim Join gesendet!");
                    }else{
                        p.sendMessage(Main.prefix+"§eBenutzung: §7/silentjoin <on/off>");
                    }
                }else{
                    p.sendMessage(Main.prefix+"§eBenutzung: §7/silentjoin <on/off>");
                }
            }else{
                p.sendMessage(Main.noperms);
            }
        }

        return false;
    }
}
