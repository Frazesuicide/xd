package at.shaderapfel.lobby.methods;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import at.shaderapfel.lobby.Main;

public class JoinItems {

	public static void giveJoinItems(Player p) {

		ItemStack i1 = new ItemStack(Material.getMaterial(Main.compassid));
		ItemMeta i1m = i1.getItemMeta();
		i1m.setDisplayName("§6Navigator §8× §7Rechtsklick");
		i1.setItemMeta(i1m);

		ItemStack i2 = new ItemStack(Material.getMaterial(Main.playerhiderid));
		ItemMeta i2m = i2.getItemMeta();
		i2m.setDisplayName("§6Sichtbarkeit §8× §7Rechtsklick");
		i2.setItemMeta(i2m);

		ItemStack i3 = new ItemStack(Material.getMaterial(Main.rankhiderid));
		ItemMeta i3m = i3.getItemMeta();
		if (Main.rankhidden.contains(p)) {
			i3m.setDisplayName("§aRang anzeigen §8× §7Rechtsklick");
		} else {
			i3m.setDisplayName("§cRang verstecken §8× §7Rechtsklick");
		}
		i3.setItemMeta(i3m);

		ItemStack i4 = new ItemStack(Material.getMaterial(Main.flymodeid));
		ItemMeta i4m = i4.getItemMeta();
		if (!Main.fly.contains(p)) {
			i4m.setDisplayName("§cFlugmodus §8× §7Rechtsklick");
		} else {
			i4m.setDisplayName("§aFlugmodus §8× §7Rechtsklick");
		}
		i4.setItemMeta(i4m);

		ItemStack i5 = new ItemStack(Material.getMaterial(Main.customItemId));
		ItemMeta i5m = i5.getItemMeta();
		i5m.setDisplayName(Main.customItemDisplayName);
		i5.setItemMeta(i5m);

		ItemStack i6;
		ItemMeta i6m;

		if (Main.enderpearl.contains(p)) {
			i6 = new ItemStack(Material.ENDER_PEARL);
			i6m = i6.getItemMeta();
			i6m.setDisplayName("§bEnderperle §8× §7Gadget");
			i6.setItemMeta(i6m);
		} else if (Main.jumpboost.contains(p)) {
			i6 = new ItemStack(Material.SLIME_BALL);
			i6m = i6.getItemMeta();
			i6m.setDisplayName("§bJumpBoost §8× §7Gadget");
			i6.setItemMeta(i6m);
		} else if (Main.mysticcannon.contains(p)) {
			i6 = new ItemStack(Material.BLAZE_ROD);
			i6m = i6.getItemMeta();
			i6m.setDisplayName("§6Mystic Cannon §8× §7Halloween-Gadget");
			i6.setItemMeta(i6m);
		} else if (Main.snowball.contains(p)) {
			i6 = new ItemStack(Material.SNOW_BALL);
			i6m = i6.getItemMeta();
			i6m.setDisplayName("§f§lSchneeball §8× §7Weihnachts-Gadget");
			i6.setItemMeta(i6m);
		} else {
			i6 = new ItemStack(Material.getMaterial(Main.nogadgetid));
			i6m = i6.getItemMeta();
			i6m.setDisplayName("§6Kein Gadget §8× §7Rechtsklick");
			i6.setItemMeta(i6m);
		}

		ItemStack i7 = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta i7m = (SkullMeta) i7.getItemMeta();
		i7m.setOwner(p.getName());
		i7m.setDisplayName("§6Profil §8× §7Rechtsklick");
		i7.setItemMeta(i7m);

		p.getInventory().clear();

		p.getInventory().setItem(0, i1);
		p.getInventory().setItem(1, i2);
		p.getInventory().setItem(7, i6);
		if(Main.customItemEnabled){
			p.getInventory().setItem(6, i5);
		}
		p.getInventory().setItem(8, i7);

		if (p.hasPermission("lobby.premium")) { // Premium

			p.getInventory().clear();

			p.getInventory().setItem(0, i1);
			p.getInventory().setItem(1, i2);
			p.getInventory().setItem(4, i4);
			p.getInventory().setItem(7, i6);
			p.getInventory().setItem(8, i7);
			if(Main.customItemEnabled){
				p.getInventory().setItem(6, i5);
			}

		}
		if (p.hasPermission("lobby.miniyoutuber")) { // PremiumPlus

			p.getInventory().clear();

			p.getInventory().setItem(0, i1);
			p.getInventory().setItem(1, i2);
			p.getInventory().setItem(2, i4);
			if(Main.customItemEnabled){
				p.getInventory().setItem(6, i5);
			}
			p.getInventory().setItem(7, i6);
			p.getInventory().setItem(8, i7);

		}
		if (p.hasPermission("lobby.youtuber")) { // YouTuber

			p.getInventory().clear();

			p.getInventory().setItem(0, i1);
			p.getInventory().setItem(1, i2);
			p.getInventory().setItem(2, i3);
			p.getInventory().setItem(4, i4);
			if(Main.customItemEnabled){
				p.getInventory().setItem(6, i5);
			}
			p.getInventory().setItem(7, i6);
			p.getInventory().setItem(8, i7);

		}
	}
}
