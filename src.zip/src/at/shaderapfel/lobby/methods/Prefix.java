package at.shaderapfel.lobby.methods;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

import at.shaderapfel.lobby.Main;

public class Prefix {

	public static void setPrefix(Player p) {

		if (Main.rankhidden.contains(p)) {
			p.setDisplayName(Main.rankspieler + " §8┃ §7" + p.getName());
		} else if (p.hasPermission("lobby.admin")) {

			p.setDisplayName(Main.rankadmin + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.developer")) {

			p.setDisplayName(Main.rankdev + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.srmoderator")) {

			p.setDisplayName(Main.ranksrmod + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.moderator")) {

			p.setDisplayName(Main.rankmod + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.supporter")) {

			p.setDisplayName(Main.ranksupporter + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.builder")) {

			p.setDisplayName(Main.rankbuilder + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.youtuber")) {

			p.setDisplayName(Main.rankyoutuber + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.miniyoutuber")) {

			p.setDisplayName(Main.rankminiyoutuber + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.ultimate")) {

			p.setDisplayName(Main.rankultimate + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.elite")) {

			p.setDisplayName(Main.rankelite + " §8┃ §7" + p.getName());

		} else if (p.hasPermission("lobby.plus")) {

			p.setDisplayName(Main.rankplus + " §8┃ §7" + p.getName());

		} else if (p.isOp()) {

			p.setDisplayName(Main.rankadmin + " §8┃ §7" + p.getName());

		} else {

			p.setDisplayName(Main.rankspieler + " §8┃ §7" + p.getName());

		}

		p.setPlayerListName("§7Lade Spieler");

		Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

			@Override
			public void run() {
				p.setPlayerListName("§7Lade Spieler.");
				Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

					@Override
					public void run() {
						p.setPlayerListName("§7Lade Spieler..");
						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								p.setPlayerListName("§7Lade Spieler...");

								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										if (Main.rankhidden.contains(p)) {
											p.setPlayerListName(Main.rankspielertab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.admin")) {
											p.setPlayerListName(Main.rankadmintab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.developer")) {
											p.setPlayerListName(Main.rankdevtab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.srmoderator")) {
											p.setPlayerListName(Main.ranksrmodtab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.moderator")) {
											p.setPlayerListName(Main.rankmodtab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.supporter")) {
											p.setPlayerListName(Main.ranksupportertab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.builder")) {
											p.setPlayerListName(Main.rankbuildertab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.youtuber")) {
											p.setPlayerListName(Main.rankyoutubertab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.miniyoutuber")) {
											p.setPlayerListName(Main.rankminiyoutubertab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.ultimate")) {
											p.setPlayerListName(Main.rankultimatetab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.elite")) {
											p.setPlayerListName(Main.rankelitetab + " §8┃ §7" + p.getName());
										} else if (p.hasPermission("lobby.plus")) {
											p.setPlayerListName(Main.rankplustab + " §8┃ §7" + p.getName());
										} else if (p.isOp()) {
											p.setPlayerListName(Main.rankadmintab + " §8┃ §7" + p.getName());
										} else {
											p.setPlayerListName(Main.rankspielertab + " §8┃ §7" + p.getName());
										}

									}
								}, 3);

							}
						}, 3);
					}
				}, 3);
			}
		}, 3);

	}

}
