package at.shaderapfel.lobby.methods;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import at.shaderapfel.lobby.Main;

public class methAutoMessengerScheduler {

	public static int count = 300;
	public static int Countdown;

	public static void startCountdown() {
		Countdown = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getInstance(), new Runnable() {

			public void run() {

				Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.instance, new Runnable() {

					@Override
					public void run() {
						if (Main.automsgon) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Main.prefix + Main.automsg1);
							}
						}
					}
				}, 0, 60 * 5 * 20 * 4);

				Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.instance, new Runnable() {

					@Override
					public void run() {
						if (Main.automsgon) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Main.prefix + Main.automsg2);
							}
						}
					}
				}, 60 * 5 * 20 * 1, 60 * 5 * 20 * 4);

				Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.instance, new Runnable() {

					@Override
					public void run() {
						if (Main.automsgon) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Main.prefix + Main.automsg3);
							}
						}
					}
				}, 60 * 5 * 20 * 2, 60 * 5 * 20 * 4);

				Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.instance, new Runnable() {

					@Override
					public void run() {
						if (Main.automsgon) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Main.prefix + Main.automsg4);
							}
						}
					}
				}, 60 * 5 * 20 * 3, 60 * 5 * 20 * 4);
			}
		}, 0, 60 * 5 * 20 * 5);
	}
}
