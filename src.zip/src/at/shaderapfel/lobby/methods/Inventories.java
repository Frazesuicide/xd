package at.shaderapfel.lobby.methods;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.utils.ItemUtils;

public class Inventories {

    public static void openCompass(Player player) {

        Inventory compass = Bukkit.createInventory(null, 4 * 9, "§6Navigator");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);

//		setGlass(player);

        compass.setItem(0, placeholder);
        compass.setItem(1, placeholder);
        compass.setItem(2, placeholder);
        compass.setItem(3, placeholder);
        compass.setItem(4, placeholder);
        compass.setItem(5, placeholder);
        compass.setItem(6, placeholder);
        compass.setItem(7, placeholder);
        compass.setItem(8, placeholder);
        compass.setItem(9, placeholder);
        compass.setItem(17, placeholder);
        compass.setItem(18, placeholder);
        compass.setItem(26, placeholder);
        compass.setItem(27, placeholder);
        compass.setItem(28, placeholder);
        compass.setItem(29, placeholder);
        compass.setItem(30, placeholder);
        compass.setItem(31, placeholder);
        compass.setItem(32, placeholder);
        compass.setItem(33, placeholder);
        compass.setItem(34, placeholder);
        compass.setItem(35, placeholder);
        if (!Main.WarpItem1Enabled) {
            compass.setItem(10, placeholder);
        }
        if (!Main.WarpItem2Enabled) {
            compass.setItem(11, placeholder);
        }
        if (!Main.WarpItem3Enabled) {
            compass.setItem(12, placeholder);
        }
        if (!Main.WarpItem4Enabled) {
            compass.setItem(13, placeholder);
        }
        if (!Main.WarpItem5Enabled) {
            compass.setItem(14, placeholder);
        }
        if (!Main.WarpItem6Enabled) {
            compass.setItem(15, placeholder);
        }
        if (!Main.WarpItem7Enabled) {
            compass.setItem(16, placeholder);
        }
        if (!Main.WarpItem8Enabled) {
            compass.setItem(19, placeholder);
        }
        if (!Main.WarpItem9Enabled) {
            compass.setItem(20, placeholder);
        }
        if (!Main.WarpItem10Enabled) {
            compass.setItem(21, placeholder);
        }
        if (!Main.WarpItem11Enabled) {
            compass.setItem(22, placeholder);
        }
        if (!Main.WarpItem12Enabled) {
            compass.setItem(23, placeholder);
        }
        if (!Main.WarpItem13Enabled) {
            compass.setItem(24, placeholder);
        }
        if (!Main.WarpItem14Enabled) {
            compass.setItem(25, placeholder);
        }

        ItemStack Item1 = ItemUtils.getItem(Main.WarpItem1, Main.WarpItem1Name,
                "§7Zu " + Main.WarpItem1Name + " §7teleportieren!", 0, 1);
        ItemStack Item2 = ItemUtils.getItem(Main.WarpItem2, Main.WarpItem2Name,
                "§7Zu " + Main.WarpItem2Name + " §7teleportieren!", 0, 1);
        ItemStack Item3 = ItemUtils.getItem(Main.WarpItem3, Main.WarpItem3Name,
                "§7Zu " + Main.WarpItem3Name + " §7teleportieren!", 0, 1);
        ItemStack Item4 = ItemUtils.getItem(Main.WarpItem4, Main.WarpItem4Name,
                "§7Zu " + Main.WarpItem4Name + " §7teleportieren!", 0, 1);
        ItemStack Item5 = ItemUtils.getItem(Main.WarpItem5, Main.WarpItem5Name,
                "§7Zu " + Main.WarpItem5Name + " §7teleportieren!", 0, 1);
        ItemStack Item6 = ItemUtils.getItem(Main.WarpItem6, Main.WarpItem6Name,
                "§7Zu " + Main.WarpItem6Name + " §7teleportieren!", 0, 1);
        ItemStack Item7 = ItemUtils.getItem(Main.WarpItem7, Main.WarpItem7Name,
                "§7Zu " + Main.WarpItem7Name + " §7teleportieren!", 0, 1);
        ItemStack Item8 = ItemUtils.getItem(Main.WarpItem8, Main.WarpItem8Name,
                "§7Zu " + Main.WarpItem8Name + " §7teleportieren!", 0, 1);
        ItemStack Item9 = ItemUtils.getItem(Main.WarpItem9, Main.WarpItem9Name,
                "§7Zu " + Main.WarpItem9Name + " §7teleportieren!", 0, 1);
        ItemStack Item10 = ItemUtils.getItem(Main.WarpItem10, Main.WarpItem10Name,
                "§7Zu " + Main.WarpItem10Name + " §7teleportieren!", 0, 1);
        ItemStack Item11 = ItemUtils.getItem(Main.WarpItem11, Main.WarpItem11Name,
                "§7Zu " + Main.WarpItem11Name + " §7teleportieren!", 0, 1);
        ItemStack Item12 = ItemUtils.getItem(Main.WarpItem12, Main.WarpItem12Name,
                "§7Zu " + Main.WarpItem12Name + " §7teleportieren!", 0, 1);
        ItemStack Item13 = ItemUtils.getItem(Main.WarpItem13, Main.WarpItem13Name,
                "§7Zu " + Main.WarpItem13Name + " §7teleportieren!", 0, 1);
        ItemStack Item14 = ItemUtils.getItem(Main.WarpItem14, Main.WarpItem14Name,
                "§7Zu " + Main.WarpItem14Name + " §7teleportieren!", 0, 1);

        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
            @Override
            public void run() {
                if (Main.WarpItem1Enabled) {
                    compass.setItem(10, Item1);
                }
                player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);

                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
                    @Override
                    public void run() {
                        if (Main.WarpItem2Enabled) {
                            compass.setItem(11, Item2);
                        }
                        player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 2);

                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
                            @Override
                            public void run() {
                                if (Main.WarpItem3Enabled) {
                                    compass.setItem(12, Item3);
                                }
                                player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);

                                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
                                    @Override
                                    public void run() {
                                        if (Main.WarpItem4Enabled) {
                                            compass.setItem(13, Item4);
                                        }
                                        player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 2);

                                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(),
                                                new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        if (Main.WarpItem5Enabled) {
                                                            compass.setItem(14, Item5);
                                                        }
                                                        player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1,
                                                                1);

                                                        Bukkit.getScheduler().scheduleSyncDelayedTask(
                                                                Main.getInstance(), new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        if (Main.WarpItem6Enabled) {
                                                                            compass.setItem(15, Item6);
                                                                        }
                                                                        player.playSound(player.getLocation(),
                                                                                Sound.CHICKEN_EGG_POP, 1, 2);

                                                                        Bukkit.getScheduler().scheduleSyncDelayedTask(
                                                                                Main.getInstance(), new Runnable() {
                                                                                    @Override
                                                                                    public void run() {
                                                                                        if (Main.WarpItem7Enabled) {
                                                                                            compass.setItem(16, Item7);
                                                                                        }
                                                                                        player.playSound(
                                                                                                player.getLocation(),
                                                                                                Sound.CHICKEN_EGG_POP,
                                                                                                1, 1);

                                                                                        Bukkit.getScheduler()
                                                                                                .scheduleSyncDelayedTask(
                                                                                                        Main.getInstance(),
                                                                                                        new Runnable() {
                                                                                                            @Override
                                                                                                            public void run() {
                                                                                                                if (Main.WarpItem8Enabled) {
                                                                                                                    compass.setItem(
                                                                                                                            19,
                                                                                                                            Item8);
                                                                                                                }
                                                                                                                player.playSound(
                                                                                                                        player.getLocation(),
                                                                                                                        Sound.CHICKEN_EGG_POP,
                                                                                                                        1,
                                                                                                                        2);

                                                                                                                Bukkit.getScheduler()
                                                                                                                        .scheduleSyncDelayedTask(
                                                                                                                                Main.getInstance(),
                                                                                                                                new Runnable() {
                                                                                                                                    @Override
                                                                                                                                    public void run() {
                                                                                                                                        if (Main.WarpItem9Enabled) {
                                                                                                                                            compass.setItem(
                                                                                                                                                    20,
                                                                                                                                                    Item9);
                                                                                                                                        }
                                                                                                                                        player.playSound(
                                                                                                                                                player.getLocation(),
                                                                                                                                                Sound.CHICKEN_EGG_POP,
                                                                                                                                                1,
                                                                                                                                                1);

                                                                                                                                        Bukkit.getScheduler()
                                                                                                                                                .scheduleSyncDelayedTask(
                                                                                                                                                        Main.getInstance(),
                                                                                                                                                        new Runnable() {
                                                                                                                                                            @Override
                                                                                                                                                            public void run() {
                                                                                                                                                                if (Main.WarpItem10Enabled) {
                                                                                                                                                                    compass.setItem(
                                                                                                                                                                            21,
                                                                                                                                                                            Item10);
                                                                                                                                                                }
                                                                                                                                                                player.playSound(
                                                                                                                                                                        player.getLocation(),
                                                                                                                                                                        Sound.CHICKEN_EGG_POP,
                                                                                                                                                                        1,
                                                                                                                                                                        2);

                                                                                                                                                                Bukkit.getScheduler()
                                                                                                                                                                        .scheduleSyncDelayedTask(
                                                                                                                                                                                Main.getInstance(),
                                                                                                                                                                                new Runnable() {
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public void run() {
                                                                                                                                                                                        if (Main.WarpItem11Enabled) {
                                                                                                                                                                                            compass.setItem(
                                                                                                                                                                                                    22,
                                                                                                                                                                                                    Item11);
                                                                                                                                                                                        }
                                                                                                                                                                                        player.playSound(
                                                                                                                                                                                                player.getLocation(),
                                                                                                                                                                                                Sound.CHICKEN_EGG_POP,
                                                                                                                                                                                                1,
                                                                                                                                                                                                1);

                                                                                                                                                                                        Bukkit.getScheduler()
                                                                                                                                                                                                .scheduleSyncDelayedTask(
                                                                                                                                                                                                        Main.getInstance(),
                                                                                                                                                                                                        new Runnable() {
                                                                                                                                                                                                            @Override
                                                                                                                                                                                                            public void run() {
                                                                                                                                                                                                                if (Main.WarpItem12Enabled) {
                                                                                                                                                                                                                    compass.setItem(
                                                                                                                                                                                                                            23,
                                                                                                                                                                                                                            Item12);
                                                                                                                                                                                                                }
                                                                                                                                                                                                                player.playSound(
                                                                                                                                                                                                                        player.getLocation(),
                                                                                                                                                                                                                        Sound.CHICKEN_EGG_POP,
                                                                                                                                                                                                                        1,
                                                                                                                                                                                                                        2);

                                                                                                                                                                                                                Bukkit.getScheduler()
                                                                                                                                                                                                                        .scheduleSyncDelayedTask(
                                                                                                                                                                                                                                Main.getInstance(),
                                                                                                                                                                                                                                new Runnable() {
                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                    public void run() {
                                                                                                                                                                                                                                        if (Main.WarpItem13Enabled) {
                                                                                                                                                                                                                                            compass.setItem(
                                                                                                                                                                                                                                                    24,
                                                                                                                                                                                                                                                    Item13);
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        player.playSound(
                                                                                                                                                                                                                                                player.getLocation(),
                                                                                                                                                                                                                                                Sound.CHICKEN_EGG_POP,
                                                                                                                                                                                                                                                1,
                                                                                                                                                                                                                                                1);

                                                                                                                                                                                                                                        Bukkit.getScheduler()
                                                                                                                                                                                                                                                .scheduleSyncDelayedTask(
                                                                                                                                                                                                                                                        Main.getInstance(),
                                                                                                                                                                                                                                                        new Runnable() {
                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                            public void run() {
                                                                                                                                                                                                                                                                if (Main.WarpItem14Enabled) {
                                                                                                                                                                                                                                                                    compass.setItem(
                                                                                                                                                                                                                                                                            25,
                                                                                                                                                                                                                                                                            Item14);
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                player.playSound(
                                                                                                                                                                                                                                                                        player.getLocation(),
                                                                                                                                                                                                                                                                        Sound.CHICKEN_EGG_POP,
                                                                                                                                                                                                                                                                        1,
                                                                                                                                                                                                                                                                        2);
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                        },
                                                                                                                                                                                                                                                        1);
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                },
                                                                                                                                                                                                                                1);
                                                                                                                                                                                                            }
                                                                                                                                                                                                        },
                                                                                                                                                                                                        1);
                                                                                                                                                                                    }
                                                                                                                                                                                },
                                                                                                                                                                                1);
                                                                                                                                                            }
                                                                                                                                                        },
                                                                                                                                                        1);
                                                                                                                                    }
                                                                                                                                },
                                                                                                                                1);
                                                                                                            }
                                                                                                        }, 1);
                                                                                    }
                                                                                }, 1);
                                                                    }
                                                                }, 1);
                                                    }
                                                }, 1);
                                    }
                                }, 1);
                            }
                        }, 1);
                    }
                }, 1);
            }
        }, 1);

        player.openInventory(compass);
    }

    public static void openPlayerHider(Player player) {

        Inventory playerhider = Bukkit.createInventory(null, InventoryType.BREWING, "§6Sichtbarkeit");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 0, 1);

//		setGlass(player);

        // playerhider.setItem(0, placeholder);
        // playerhider.setItem(1, placeholder);
        // playerhider.setItem(2, placeholder);

        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

            @Override
            public void run() {
                playerhider.setItem(3, ItemUtils.getItemWithID(130, "§6Welche Spieler möchtest du sehen?",
                        "§7Wähle sie hier aus!", 0, 1));
                player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1, 1);
                player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 1);

                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
                    @Override
                    public void run() {
                        playerhider.setItem(0, ItemUtils.getItemWithID(351, "§aAlle Spieler anzeigen",
                                "§7Klicke um auszuwählen!", 10, 1));
                        player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1, 1);
                        player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 2);

                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
                            @Override
                            public void run() {
                                playerhider.setItem(1, ItemUtils.getItemWithID(351, "§5VIP Spieler anzeigen",
                                        "§7Klicke um auszuwählen!", 5, 1));
                                player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1, 1);
                                player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 3);

                                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {
                                    @Override
                                    public void run() {
                                        playerhider.setItem(2, ItemUtils.getItemWithID(351, "§cKeine Spieler anzeigen",
                                                "§7Klicke um auszuwählen!", 8, 1));
                                        player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1, 1);
                                        player.playSound(player.getLocation(), Sound.NOTE_PLING, 1, 4);

                                    }
                                }, 2);

                            }
                        }, 2);

                    }
                }, 2);

            }
        }, 2);

        // playerhider.setItem(6, placeholder);
        // playerhider.setItem(7, placeholder);
        // playerhider.setItem(8, placeholder);

        player.openInventory(playerhider);
    }

    public static void openProfil(Player player) {

        Inventory profil = Bukkit.createInventory(null, 5 * 9, "§6Profil");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
//		setGlass(player);

        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

            @Override
            public void run() {
                profil.setItem(13 + 9, ItemUtils.getItem(Material.ACACIA_DOOR_ITEM, "§eLobby-Switcher", "§7Hier kannst du die Lobby wechseln!", 0, 1));
                player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);

                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                    @Override
                    public void run() {

                        profil.setItem(20, ItemUtils.getItem(Material.FIREBALL, "§6Gadgets",
                                "§7Hier gibt es coole\n§7Extras für dich!", 0, 1));

                        player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);

                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                            @Override
                            public void run() {
                                profil.setItem(24, ItemUtils.getItem(Material.WORKBENCH, "§aFreunde",
                                        "§7Hier werden deine Freunde angezeigt!", 0, 1));
                                player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);

                                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                                    @Override
                                    public void run() {
                                        profil.setItem(30, ItemUtils.getItem(Material.IRON_CHESTPLATE,
                                                "§eKleiderschrank", "§7Hier kannst du dein Outfit anpassen!", 0, 1));
                                        player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);
                                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(),
                                                new Runnable() {

                                                    @Override
                                                    public void run() {
                                                        profil.setItem(32,
                                                                ItemUtils.getItem(Material.GOLD_INGOT, "§2Effekt-Items",
                                                                        "§7Hier kannst du dir coole Drop-Effekte holen!",
                                                                        0, 1));
                                                        player.playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 1,
                                                                1);

                                                        Bukkit.getScheduler().scheduleSyncDelayedTask(
                                                                Main.getInstance(), new Runnable() {

                                                                    @Override
                                                                    public void run() {
                                                                        profil.setItem(12,
                                                                                ItemUtils.getHead("Paluten", "§3Köpfe",
                                                                                        "§7Hier kannst du dir coole Kopfe holen!",
                                                                                        1));
                                                                        player.playSound(player.getLocation(),
                                                                                Sound.CHICKEN_EGG_POP, 1, 1);

                                                                        Bukkit.getScheduler().scheduleSyncDelayedTask(
                                                                                Main.getInstance(), new Runnable() {

                                                                                    @Override
                                                                                    public void run() {
                                                                                        profil.setItem(14,
                                                                                                ItemUtils.getItem(
                                                                                                        Material.GOLD_BOOTS,
                                                                                                        "§cTrails",
                                                                                                        "§7Hier kannst du eine bunte Spur aktivieren!",
                                                                                                        0, 1));
                                                                                        player.playSound(
                                                                                                player.getLocation(),
                                                                                                Sound.CHICKEN_EGG_POP,
                                                                                                1, 1);

                                                                                    }
                                                                                }, 2);

                                                                    }
                                                                }, 2);

                                                    }
                                                }, 2);

                                    }
                                }, 2);

                            }
                        }, 2);
                    }
                }, 2);

            }
        }, 2);

        profil.setItem(0, placeholder);
        profil.setItem(1, placeholder);
        profil.setItem(2, placeholder);
        profil.setItem(3, placeholder);
        profil.setItem(4, placeholder);
        profil.setItem(5, placeholder);
        profil.setItem(6, placeholder);
        profil.setItem(7, placeholder);
        profil.setItem(8, placeholder);
        profil.setItem(9, placeholder);
        profil.setItem(10, placeholder);
        profil.setItem(11, placeholder);
        profil.setItem(12, placeholder);
        profil.setItem(13, placeholder);
        profil.setItem(14, placeholder);
        profil.setItem(15, placeholder);
        profil.setItem(16, placeholder);
        profil.setItem(17, placeholder);
        profil.setItem(18, placeholder);
        profil.setItem(19, placeholder);
        profil.setItem(20, placeholder);
        profil.setItem(21, placeholder);
        profil.setItem(22, placeholder);
        profil.setItem(23, placeholder);
        profil.setItem(24, placeholder);
        profil.setItem(25, placeholder);
        profil.setItem(26, placeholder);
        profil.setItem(27, placeholder);
        profil.setItem(28, placeholder);
        profil.setItem(29, placeholder);
        profil.setItem(30, placeholder);
        profil.setItem(31, placeholder);
        profil.setItem(32, placeholder);
        profil.setItem(33, placeholder);
        profil.setItem(34, placeholder);
        profil.setItem(35, placeholder);
        profil.setItem(36, placeholder);
        profil.setItem(37, placeholder);
        profil.setItem(38, placeholder);
        profil.setItem(39, placeholder);
        profil.setItem(40, placeholder);
        profil.setItem(41, placeholder);
        profil.setItem(42, placeholder);
        profil.setItem(43, placeholder);
        profil.setItem(44, placeholder);

        player.openInventory(profil);
    }

    public static void openGadgets(Player player) {
        Inventory gadgets = Bukkit.createInventory(null, 3 * 9, "§6Gadgets");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
//		setGlass(player);

        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

            @Override
            public void run() {
                gadgets.setItem(10, ItemUtils.getItem(Material.ENDER_PEARL, "§bEnderperle §8× §7Gadget",
                        "§7Teleportiere dich damit\n§7quer durch die Lobby!", 0, 1));
                player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                    @Override
                    public void run() {
                        gadgets.setItem(11, ItemUtils.getItem(Material.SLIME_BALL, "§bJumpBoost §8× §7Gadget",
                                "§7Springe damit quer\n§7durch die Lobby!", 0, 1));
                        player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                            @Override
                            public void run() {
                                gadgets.setItem(12,
                                        ItemUtils.getItem(Material.BLAZE_ROD, "§6Mystic Cannon §8× §7Halloween-Gadget",
                                                "§7Du willst deine Mitspieler mal so richtig erschrecken?\n§7Dann ist dieses Item genau das Richtige für dich!",
                                                0, 1));
                                player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

                                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                                    @Override
                                    public void run() {
                                        gadgets.setItem(13,
                                                ItemUtils.getItem(Material.SNOW_BALL, "§f§lSchneeball §8× §7Weihnachts-Gadget",
                                                        "§7Mehr als der normale Vanilla-Schneeball ;)",
                                                        0, 1));
                                        player.playSound(player.getLocation(), Sound.CLICK, 1, 1);
                                        // Wer das liest ist dumm

                                        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

                                            @Override
                                            public void run() {
                                                gadgets.setItem(16,
                                                        ItemUtils.getItem(Material.LAVA_BUCKET, "§cGadget entfernen!",
                                                                "§7Du hast keinen Bock mehr?\n§7Dann ist dieses Item genau das Richtige für dich!",
                                                                0, 1));
                                                player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

                                            }
                                        }, 3);

                                    }
                                }, 3);

                            }
                        }, 3);

                    }
                }, 3);

            }
        }, 3);

        gadgets.setItem(0, placeholder);
        gadgets.setItem(1, placeholder);
        gadgets.setItem(2, placeholder);
        gadgets.setItem(3, placeholder);
        gadgets.setItem(4, placeholder);
        gadgets.setItem(5, placeholder);
        gadgets.setItem(6, placeholder);
        gadgets.setItem(7, placeholder);
        gadgets.setItem(8, placeholder);
        gadgets.setItem(18, placeholder);
        gadgets.setItem(19, placeholder);
        gadgets.setItem(20, placeholder);
        gadgets.setItem(21, placeholder);
        gadgets.setItem(22, placeholder);
        gadgets.setItem(23, placeholder);
        gadgets.setItem(24, placeholder);
        gadgets.setItem(24, placeholder);
        gadgets.setItem(25, placeholder);
        gadgets.setItem(26, placeholder);

        player.openInventory(gadgets);
    }

    public static void openDrops(Player player) {
        Inventory drops = Bukkit.createInventory(null, 4 * 9, "§6Drop-Effekte");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
//		setGlass(player);
        drops.setItem(0, placeholder);
        drops.setItem(1, placeholder);
        drops.setItem(2, placeholder);
        drops.setItem(3, placeholder);
        drops.setItem(4, placeholder);
        drops.setItem(5, placeholder);
        drops.setItem(6, placeholder);
        drops.setItem(7, placeholder);
        drops.setItem(8, placeholder);
        drops.setItem(9, placeholder);
        drops.setItem(10, placeholder);
        drops.setItem(11, placeholder);
        drops.setItem(12, placeholder);
        drops.setItem(13, placeholder);
        drops.setItem(14, placeholder);
        drops.setItem(15, placeholder);
        drops.setItem(16, placeholder);
        drops.setItem(17, placeholder);
        drops.setItem(18, placeholder);
        drops.setItem(19, placeholder);
        drops.setItem(20, placeholder);
        drops.setItem(21, placeholder);
        drops.setItem(22, placeholder);
        drops.setItem(23, placeholder);
        drops.setItem(24, placeholder);
        drops.setItem(24, placeholder);
        drops.setItem(25, placeholder);
        drops.setItem(26, placeholder);
        drops.setItem(27, placeholder);
        drops.setItem(28, placeholder);
        drops.setItem(29, placeholder);
        drops.setItem(30, placeholder);
        drops.setItem(31, placeholder);
        drops.setItem(32, placeholder);
        drops.setItem(33, placeholder);
        drops.setItem(34, placeholder);
        drops.setItem(35, placeholder);

        drops.setItem(12,
                ItemUtils.getItem(Material.GOLD_NUGGET, "§6Golden", "§7Dieser Drop-Effekt folgt dir immer!", 0, 1));
        if (Main.golddrops.contains(player)) {
            drops.setItem(12 + 9, ItemUtils.getItemWithID(351, "§aAktiviert",
                    "§eKlicken um goldenen Effekt zu deaktivieren!", 10, 1));
        } else {
            drops.setItem(12 + 9,
                    ItemUtils.getItemWithID(351, "§cDeaktiviert", "§eKlicken um goldenen Effekt zu aktivieren!", 8, 1));
        }

        player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

        drops.setItem(14,
                ItemUtils.getItem(Material.REDSTONE, "§cRot", "§7Dieser Drop-Effekt folgt dir immer!", 0, 1));
        if (Main.reddrops.contains(player)) {
            drops.setItem(14 + 9,
                    ItemUtils.getItemWithID(351, "§aAktiviert", "§eKlicken um roten Effekt zu deaktivieren!", 10, 1));
        } else {
            drops.setItem(14 + 9,
                    ItemUtils.getItemWithID(351, "§cDeaktiviert", "§eKlicken um roten Effekt zu aktivieren!", 8, 1));
        }

        player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

        player.openInventory(drops);
    }

    public static void openKleiderschrank(Player player) {

        Inventory kleiderschrank = Bukkit.createInventory(null, 6 * 9, "§6Kleiderschrank");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
//		setGlass(player);

        ItemStack helm1 = new ItemStack(Material.LEATHER_HELMET);
        LeatherArmorMeta helmmeta1 = (LeatherArmorMeta) helm1.getItemMeta();
        helmmeta1.setColor(Color.RED);
        helmmeta1.setDisplayName("§cRoter Helm");
        helm1.setItemMeta(helmmeta1);

        ItemStack halloween = ItemUtils.getItem(Material.PUMPKIN, "§6HALLOWEEN UPDATE",
                "§cDie Helme sind nach\n§cHalloween wieder verfügbar!\n\n§3- Serverleitung", 0, 1);

        ItemStack chest1 = new ItemStack(Material.LEATHER_CHESTPLATE);
        LeatherArmorMeta chestmeta1 = (LeatherArmorMeta) chest1.getItemMeta();
        chestmeta1.setColor(Color.RED);
        chestmeta1.setDisplayName("§cRote Brustplatte");
        chest1.setItemMeta(chestmeta1);

        ItemStack leggins1 = new ItemStack(Material.LEATHER_LEGGINGS);
        LeatherArmorMeta legginsmeta1 = (LeatherArmorMeta) leggins1.getItemMeta();
        legginsmeta1.setColor(Color.RED);
        legginsmeta1.setDisplayName("§cRote Hose");
        leggins1.setItemMeta(legginsmeta1);

        ItemStack boots1 = new ItemStack(Material.LEATHER_BOOTS);
        LeatherArmorMeta bootsmeta1 = (LeatherArmorMeta) boots1.getItemMeta();
        bootsmeta1.setColor(Color.RED);
        bootsmeta1.setDisplayName("§cRote Schuhe");
        boots1.setItemMeta(bootsmeta1);

        ItemStack helm11 = new ItemStack(Material.LEATHER_HELMET);
        LeatherArmorMeta helmmeta11 = (LeatherArmorMeta) helm11.getItemMeta();
        helmmeta11.setColor(Color.AQUA);
        helmmeta11.setDisplayName("§3Türkiser Helm");
        helm11.setItemMeta(helmmeta11);

        ItemStack chest11 = new ItemStack(Material.LEATHER_CHESTPLATE);
        LeatherArmorMeta chestmeta11 = (LeatherArmorMeta) chest11.getItemMeta();
        chestmeta11.setColor(Color.AQUA);
        chestmeta11.setDisplayName("§3Türkise Brustplatte");
        chest11.setItemMeta(chestmeta11);

        ItemStack leggins11 = new ItemStack(Material.LEATHER_LEGGINGS);
        LeatherArmorMeta legginsmeta11 = (LeatherArmorMeta) leggins11.getItemMeta();
        legginsmeta11.setColor(Color.AQUA);
        legginsmeta11.setDisplayName("§3Türkise Hose");
        leggins11.setItemMeta(legginsmeta11);

        ItemStack boots11 = new ItemStack(Material.LEATHER_BOOTS);
        LeatherArmorMeta bootsmeta11 = (LeatherArmorMeta) boots11.getItemMeta();
        bootsmeta11.setColor(Color.AQUA);
        bootsmeta11.setDisplayName("§3Türkise Schuhe");
        boots11.setItemMeta(bootsmeta11);

        ItemStack helm111 = new ItemStack(Material.LEATHER_HELMET);
        LeatherArmorMeta helmmeta111 = (LeatherArmorMeta) helm111.getItemMeta();
        helmmeta111.setColor(Color.GREEN);
        helmmeta111.setDisplayName("§aGrüner Helm");
        helm111.setItemMeta(helmmeta111);

        ItemStack chest111 = new ItemStack(Material.LEATHER_CHESTPLATE);
        LeatherArmorMeta chestmeta111 = (LeatherArmorMeta) chest111.getItemMeta();
        chestmeta111.setColor(Color.GREEN);
        chestmeta111.setDisplayName("§aGrüne Brustplatte");
        chest111.setItemMeta(chestmeta111);

        ItemStack leggins111 = new ItemStack(Material.LEATHER_LEGGINGS);
        LeatherArmorMeta legginsmeta111 = (LeatherArmorMeta) leggins111.getItemMeta();
        legginsmeta111.setColor(Color.GREEN);
        legginsmeta111.setDisplayName("§aGrüne Hose");
        leggins111.setItemMeta(legginsmeta111);

        ItemStack boots111 = new ItemStack(Material.LEATHER_BOOTS);
        LeatherArmorMeta bootsmeta111 = (LeatherArmorMeta) boots111.getItemMeta();
        bootsmeta111.setColor(Color.GREEN);
        bootsmeta111.setDisplayName("§aGrüne Schuhe");
        boots111.setItemMeta(bootsmeta111);

        ItemStack helm1111 = new ItemStack(Material.LEATHER_HELMET);
        LeatherArmorMeta helmmeta1111 = (LeatherArmorMeta) helm1111.getItemMeta();
        helmmeta1111.setColor(Color.WHITE);
        helmmeta1111.setDisplayName("§fWeißer Helm");
        helm1111.setItemMeta(helmmeta1111);

        ItemStack chest1111 = new ItemStack(Material.LEATHER_CHESTPLATE);
        LeatherArmorMeta chestmeta1111 = (LeatherArmorMeta) chest1111.getItemMeta();
        chestmeta1111.setColor(Color.WHITE);
        chestmeta1111.setDisplayName("§fWeiße Brustplatte");
        chest1111.setItemMeta(chestmeta1111);

        ItemStack leggins1111 = new ItemStack(Material.LEATHER_LEGGINGS);
        LeatherArmorMeta legginsmeta1111 = (LeatherArmorMeta) leggins1111.getItemMeta();
        legginsmeta1111.setColor(Color.WHITE);
        legginsmeta1111.setDisplayName("§fWeiße Hose");
        leggins1111.setItemMeta(legginsmeta1111);

        ItemStack boots1111 = new ItemStack(Material.LEATHER_BOOTS);
        LeatherArmorMeta bootsmeta1111 = (LeatherArmorMeta) boots1111.getItemMeta();
        bootsmeta1111.setColor(Color.WHITE);
        bootsmeta1111.setDisplayName("§fWeiße Schuhe");
        boots1111.setItemMeta(bootsmeta1111);

        // kleiderschrank.setItem(10, halloween);
        kleiderschrank.setItem(10, helm1);
        kleiderschrank.setItem(11, chest1);
        kleiderschrank.setItem(12, leggins1);
        kleiderschrank.setItem(13, boots1);

        // kleiderschrank.setItem(10 + 9, halloween);
        kleiderschrank.setItem(10 + 9, helm11);
        kleiderschrank.setItem(11 + 9, chest11);
        kleiderschrank.setItem(12 + 9, leggins11);
        kleiderschrank.setItem(13 + 9, boots11);

        // kleiderschrank.setItem(10 + 18, halloween);
        kleiderschrank.setItem(10 + 18, helm111);
        kleiderschrank.setItem(11 + 18, chest111);
        kleiderschrank.setItem(12 + 18, leggins111);
        kleiderschrank.setItem(13 + 18, boots111);

        // kleiderschrank.setItem(10 + 27, halloween);
        kleiderschrank.setItem(10 + 27, helm1111);
        kleiderschrank.setItem(11 + 27, chest1111);
        kleiderschrank.setItem(12 + 27, leggins1111);
        kleiderschrank.setItem(13 + 27, boots1111);

        // kleiderschrank.setItem(15, halloween);
        kleiderschrank.setItem(15, ItemUtils.getItem(Material.BARRIER, "§cHelm entfernen", " ", 0, 1));
        kleiderschrank.setItem(15 + 9, ItemUtils.getItem(Material.BARRIER, "§cBrustplatte entfernen", " ", 0, 1));
        kleiderschrank.setItem(15 + 9 + 9, ItemUtils.getItem(Material.BARRIER, "§cHose entfernen", " ", 0, 1));
        kleiderschrank.setItem(15 + 9 + 9 + 9, ItemUtils.getItem(Material.BARRIER, "§cSchuhe entfernen", " ", 0, 1));

        // kleiderschrank.setItem(16, halloween);
        kleiderschrank.setItem(16, ItemUtils.getItem(Material.IRON_HELMET, "§cHelm entfernen", " ", 0, 1));
        kleiderschrank.setItem(16 + 9,
                ItemUtils.getItem(Material.IRON_CHESTPLATE, "§cBrustplatte entfernen", " ", 0, 1));
        kleiderschrank.setItem(16 + 9 + 9, ItemUtils.getItem(Material.IRON_LEGGINGS, "§cHose entfernen", " ", 0, 1));
        kleiderschrank.setItem(16 + 9 + 9 + 9, ItemUtils.getItem(Material.IRON_BOOTS, "§cSchuhe entfernen", " ", 0, 1));

        kleiderschrank.setItem(0, placeholder);
        kleiderschrank.setItem(1, placeholder);
        kleiderschrank.setItem(2, placeholder);
        kleiderschrank.setItem(3, placeholder);
        kleiderschrank.setItem(4, placeholder);
        kleiderschrank.setItem(5, placeholder);
        kleiderschrank.setItem(6, placeholder);
        kleiderschrank.setItem(7, placeholder);
        kleiderschrank.setItem(8, placeholder);
        kleiderschrank.setItem(9, placeholder);
        kleiderschrank.setItem(14, placeholder);
        kleiderschrank.setItem(17, placeholder);
        kleiderschrank.setItem(9 + 9, placeholder);
        kleiderschrank.setItem(14 + 9, placeholder);
        kleiderschrank.setItem(17 + 9, placeholder);
        kleiderschrank.setItem(9 + 9 + 9, placeholder);
        kleiderschrank.setItem(14 + 9 + 9, placeholder);
        kleiderschrank.setItem(17 + 9 + 9, placeholder);
        kleiderschrank.setItem(9 + 9 + 9 + 9, placeholder);
        kleiderschrank.setItem(14 + 9 + 9 + 9, placeholder);
        kleiderschrank.setItem(17 + 9 + 9 + 9, placeholder);
        kleiderschrank.setItem(45, placeholder);
        kleiderschrank.setItem(46, placeholder);
        kleiderschrank.setItem(47, placeholder);
        kleiderschrank.setItem(48, placeholder);
        kleiderschrank.setItem(49, placeholder);
        kleiderschrank.setItem(50, placeholder);
        kleiderschrank.setItem(51, placeholder);
        kleiderschrank.setItem(52, placeholder);
        kleiderschrank.setItem(53, placeholder);
        // kleiderschrank.setItem(18, placeholder);
        // kleiderschrank.setItem(19, placeholder);
        // kleiderschrank.setItem(20, placeholder);
        // kleiderschrank.setItem(21, placeholder);
        // kleiderschrank.setItem(22, placeholder);
        // kleiderschrank.setItem(23, placeholder);
        // kleiderschrank.setItem(24, placeholder);
        // kleiderschrank.setItem(24, placeholder);
        // kleiderschrank.setItem(25, placeholder);
        // kleiderschrank.setItem(26, placeholder);

        player.openInventory(kleiderschrank);
    }

    public static void setGlasss(Player player) {

        player.getInventory().clear();
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
        player.getInventory().setItem(0, placeholder);
        player.getInventory().setItem(1, placeholder);
        player.getInventory().setItem(2, placeholder);
        player.getInventory().setItem(3, placeholder);
        player.getInventory().setItem(4, placeholder);
        player.getInventory().setItem(5, placeholder);
        player.getInventory().setItem(6, placeholder);
        player.getInventory().setItem(7, placeholder);
        player.getInventory().setItem(8, placeholder);
        player.getInventory().setItem(9, placeholder);
        player.getInventory().setItem(10, placeholder);
        player.getInventory().setItem(11, placeholder);
        player.getInventory().setItem(12, placeholder);
        player.getInventory().setItem(13, placeholder);
        player.getInventory().setItem(14, placeholder);
        player.getInventory().setItem(15, placeholder);
        player.getInventory().setItem(16, placeholder);
        player.getInventory().setItem(17, placeholder);
        player.getInventory().setItem(18, placeholder);
        player.getInventory().setItem(19, placeholder);
        player.getInventory().setItem(20, placeholder);
        player.getInventory().setItem(21, placeholder);
        player.getInventory().setItem(22, placeholder);
        player.getInventory().setItem(23, placeholder);
        player.getInventory().setItem(24, placeholder);
        player.getInventory().setItem(25, placeholder);
        player.getInventory().setItem(26, placeholder);
        player.getInventory().setItem(27, placeholder);
        player.getInventory().setItem(28, placeholder);
        player.getInventory().setItem(29, placeholder);
        player.getInventory().setItem(30, placeholder);
        player.getInventory().setItem(31, placeholder);
        player.getInventory().setItem(32, placeholder);
        player.getInventory().setItem(33, placeholder);
        player.getInventory().setItem(34, placeholder);
        player.getInventory().setItem(35, placeholder);

    }

    public static void openHeads(Player player) {

        Inventory skullinv = Bukkit.createInventory(null, 6 * 9, "§6Köpfe");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
        ItemStack placeholder2 = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 8, 1);
//		setGlass(player);

        skullinv.setItem(10,
                ItemUtils.getHead(Main.skullplayername1, Main.skullname1, "§eKopf von §7" + Main.skullplayername1, 1));
        skullinv.setItem(11,
                ItemUtils.getHead(Main.skullplayername2, Main.skullname2, "§eKopf von §7" + Main.skullplayername2, 1));
        skullinv.setItem(12,
                ItemUtils.getHead(Main.skullplayername3, Main.skullname3, "§eKopf von §7" + Main.skullplayername3, 1));
        skullinv.setItem(13,
                ItemUtils.getHead(Main.skullplayername4, Main.skullname4, "§eKopf von §7" + Main.skullplayername4, 1));
        skullinv.setItem(14,
                ItemUtils.getHead(Main.skullplayername5, Main.skullname5, "§eKopf von §7" + Main.skullplayername5, 1));
        skullinv.setItem(15,
                ItemUtils.getHead(Main.skullplayername6, Main.skullname6, "§eKopf von §7" + Main.skullplayername6, 1));
        skullinv.setItem(16,
                ItemUtils.getHead(Main.skullplayername7, Main.skullname7, "§eKopf von §7" + Main.skullplayername7, 1));

        skullinv.setItem(10 + 9,
                ItemUtils.getHead(Main.skullplayername8, Main.skullname8, "§eKopf von §7" + Main.skullplayername8, 1));
        skullinv.setItem(11 + 9,
                ItemUtils.getHead(Main.skullplayername9, Main.skullname9, "§eKopf von §7" + Main.skullplayername9, 1));
        skullinv.setItem(12 + 9, ItemUtils.getHead(Main.skullplayername10, Main.skullname10,
                "§eKopf von §7" + Main.skullplayername10, 1));
        skullinv.setItem(13 + 9, ItemUtils.getHead(Main.skullplayername11, Main.skullname11,
                "§eKopf von §7" + Main.skullplayername11, 1));
        skullinv.setItem(14 + 9, ItemUtils.getHead(Main.skullplayername12, Main.skullname12,
                "§eKopf von §7" + Main.skullplayername12, 1));
        skullinv.setItem(15 + 9, ItemUtils.getHead(Main.skullplayername13, Main.skullname13,
                "§eKopf von §7" + Main.skullplayername13, 1));
        skullinv.setItem(16 + 9, ItemUtils.getHead(Main.skullplayername14, Main.skullname14,
                "§eKopf von §7" + Main.skullplayername14, 1));

        skullinv.setItem(10 + 9 + 9, ItemUtils.getHead(Main.skullplayername15, Main.skullname15,
                "§eKopf von §7" + Main.skullplayername15, 1));
        skullinv.setItem(11 + 9 + 9, ItemUtils.getHead(Main.skullplayername16, Main.skullname16,
                "§eKopf von §7" + Main.skullplayername16, 1));
        skullinv.setItem(12 + 9 + 9, ItemUtils.getHead(Main.skullplayername17, Main.skullname17,
                "§eKopf von §7" + Main.skullplayername17, 1));
        skullinv.setItem(13 + 9 + 9, ItemUtils.getHead(Main.skullplayername18, Main.skullname18,
                "§eKopf von §7" + Main.skullplayername18, 1));
        skullinv.setItem(14 + 9 + 9, ItemUtils.getHead(Main.skullplayername19, Main.skullname19,
                "§eKopf von §7" + Main.skullplayername19, 1));
        skullinv.setItem(15 + 9 + 9, ItemUtils.getHead(Main.skullplayername20, Main.skullname20,
                "§eKopf von §7" + Main.skullplayername20, 1));
        skullinv.setItem(16 + 9 + 9, ItemUtils.getHead(Main.skullplayername21, Main.skullname21,
                "§eKopf von §7" + Main.skullplayername21, 1));

        skullinv.setItem(0, placeholder);
        skullinv.setItem(1, placeholder);
        skullinv.setItem(2, placeholder);
        skullinv.setItem(3, placeholder);
        skullinv.setItem(4, placeholder);
        skullinv.setItem(5, placeholder);
        skullinv.setItem(6, placeholder);
        skullinv.setItem(7, placeholder);
        skullinv.setItem(8, placeholder);

        skullinv.setItem(0 + 9, placeholder);
        skullinv.setItem(8 + 9, placeholder);

        skullinv.setItem(0 + 18, placeholder);
        skullinv.setItem(8 + 18, placeholder);

        skullinv.setItem(0 + 18 + 9, placeholder);
        skullinv.setItem(8 + 18 + 9, placeholder);

        skullinv.setItem(0 + 9 * 4, placeholder);
        skullinv.setItem(1 + 9 * 4, placeholder);
        skullinv.setItem(2 + 9 * 4, placeholder);
        skullinv.setItem(3 + 9 * 4, placeholder);
        skullinv.setItem(4 + 9 * 4, placeholder);
        skullinv.setItem(5 + 9 * 4, placeholder);
        skullinv.setItem(6 + 9 * 4, placeholder);
        skullinv.setItem(7 + 9 * 4, placeholder);
        skullinv.setItem(8 + 9 * 4, placeholder);

        skullinv.setItem(45, ItemUtils.getItem(Material.BARRIER, "§cKopf entfernen",
                "§7Klicke hier um\n§7deinen Kopf zu entfernen!", 0, 1));
        skullinv.setItem(46, placeholder2);
        skullinv.setItem(47, placeholder2);
        skullinv.setItem(48, placeholder2);
        skullinv.setItem(49, placeholder2);
        skullinv.setItem(50, placeholder2);
        skullinv.setItem(51, placeholder2);
        skullinv.setItem(52, placeholder2);
        skullinv.setItem(53, ItemUtils.getHead("MHF_ArrowLeft", "§cZurück", "§7Zurück zum Hauptmenü!", 1));
        // kleiderschrank.setItem(18, placeholder);
        // kleiderschrank.setItem(19, placeholder);
        // kleiderschrank.setItem(20, placeholder);
        // kleiderschrank.setItem(21, placeholder);
        // kleiderschrank.setItem(22, placeholder);
        // kleiderschrank.setItem(23, placeholder);
        // kleiderschrank.setItem(24, placeholder);
        // kleiderschrank.setItem(24, placeholder);
        // kleiderschrank.setItem(25, placeholder);
        // kleiderschrank.setItem(26, placeholder);

        player.openInventory(skullinv);
    }

    public static void openTrails(Player player) {
        Inventory trails = Bukkit.createInventory(null, 4 * 9, "§6Trails");
        ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
//		setGlass(player);
        trails.setItem(0, placeholder);
        trails.setItem(1, placeholder);
        trails.setItem(2, placeholder);
        trails.setItem(3, placeholder);
        trails.setItem(4, placeholder);
        trails.setItem(5, placeholder);
        trails.setItem(6, placeholder);
        trails.setItem(7, placeholder);
        trails.setItem(8, placeholder);
        trails.setItem(9, placeholder);
        trails.setItem(10, placeholder);
        trails.setItem(11, placeholder);
        trails.setItem(12, placeholder);
        trails.setItem(13, placeholder);
        trails.setItem(14, placeholder);
        trails.setItem(15, placeholder);
        trails.setItem(16, placeholder);
        trails.setItem(17, placeholder);
        trails.setItem(18, placeholder);
        trails.setItem(19, placeholder);
        trails.setItem(20, placeholder);
        trails.setItem(21, placeholder);
        trails.setItem(22, placeholder);
        trails.setItem(23, placeholder);
        trails.setItem(24, placeholder);
        trails.setItem(24, placeholder);
        trails.setItem(25, placeholder);
        trails.setItem(26, placeholder);
        trails.setItem(27, placeholder);
        trails.setItem(28, placeholder);
        trails.setItem(29, placeholder);
        trails.setItem(30, placeholder);
        trails.setItem(31, placeholder);
        trails.setItem(32, placeholder);
        trails.setItem(33, placeholder);
        trails.setItem(34, placeholder);
        trails.setItem(35, placeholder);

        trails.setItem(12,
                ItemUtils.getItem(Material.GOLD_NUGGET, "§6Flammen", "§7Dieses Trail folgt dir immer!", 0, 1));
        if (Main.flametrail.contains(player)) {
            trails.setItem(12 + 9, ItemUtils.getItemWithID(351, "§aAktiviert",
                    "§eKlicken um das Flammen-Trail zu deaktivieren!", 10, 1));
        } else {
            trails.setItem(12 + 9,
                    ItemUtils.getItemWithID(351, "§cDeaktiviert", "§eKlicken um das Flammen-Trail zu aktivieren!", 8, 1));
        }


        trails.setItem(14,
                ItemUtils.getItem(Material.RED_ROSE, "§cHerzen", "§7Dieses Trail folgt dir immer!", 0, 1));
        if (Main.lovetrail.contains(player)) {
            trails.setItem(14 + 9,
                    ItemUtils.getItemWithID(351, "§aAktiviert", "§eKlicken um das Herz-Trail zu deaktivieren!", 10, 1));
        } else {
            trails.setItem(14 + 9,
                    ItemUtils.getItemWithID(351, "§cDeaktiviert", "§eKlicken um das Herz-Trail zu aktivieren!", 8, 1));
        }

        trails.setItem(13,
                ItemUtils.getItem(Material.STRING, "§7Rauch", "§7Dieses Trail folgt dir immer!", 0, 1));
        if (Main.smoketrail.contains(player)) {
            trails.setItem(13 + 9,
                    ItemUtils.getItemWithID(351, "§aAktiviert", "§eKlicken um das Rauch-Trail zu deaktivieren!", 10, 1));
        } else {
            trails.setItem(13 + 9,
                    ItemUtils.getItemWithID(351, "§cDeaktiviert", "§eKlicken um das Rauch-Trail zu aktivieren!", 8, 1));
        }

        player.playSound(player.getLocation(), Sound.CLICK, 1, 1);

        player.openInventory(trails);
    }

    public static void openLobbySwitcher(Player player) {
        Inventory inv = Bukkit.createInventory(null, InventoryType.HOPPER, "§eLobby-Switcher");
        ItemStack placeholder = ItemUtils.getItem(Material.BARRIER, "Server deaktiviert!", "", 15, 1);
        ItemStack server1 = ItemUtils.getItem(Material.ACACIA_DOOR_ITEM, "§eLobby 1", "§7Connecten!", 0, 1);
        ItemStack server2 = ItemUtils.getItem(Material.ACACIA_DOOR_ITEM, "§eLobby 2", "§7Connecten!", 0, 1);
        ItemStack server3 = ItemUtils.getItem(Material.ACACIA_DOOR_ITEM, "§eLobby 3", "§7Connecten!", 0, 1);
        ItemStack server4 = ItemUtils.getItem(Material.ACACIA_DOOR_ITEM, "§eLobby 4", "§7Connecten!", 0, 1);
        ItemStack silenthub = ItemUtils.getItem(Material.TNT, "§eSilentHub", "§7Connecten!", 0, 1);
        ItemStack currentserver = ItemUtils.getItem(Material.BEACON, "§cAktueller Server", "§7Verbunden!", 0, 1);

        inv.setItem(0, placeholder);
        inv.setItem(1, placeholder);
        inv.setItem(2, placeholder);
        inv.setItem(3, placeholder);
        inv.setItem(4, placeholder);
        if(Main.Server1Activated){
            inv.setItem(0, server1);
        }
        if(Main.Server2Activated){
            inv.setItem(1, server2);
        }
        if(Main.Server3Activated){
            inv.setItem(2, server3);
        }
        if(Main.Server4Activated){
            inv.setItem(3, server4);
        }
        if(Main.SilentHubActivated){
            inv.setItem(4, silenthub);
        }

        if(Main.IsServer1){
            inv.setItem(0, currentserver);
        }
        if(Main.IsServer2){
            inv.setItem(1, currentserver);
        }
        if(Main.IsServer3){
            inv.setItem(2, currentserver);
        }
        if(Main.IsServer4){
            inv.setItem(3, currentserver);
        }
        if(Main.IsSilentHub){
            inv.setItem(4, currentserver);
        }

        player.openInventory(inv);
    }
}
