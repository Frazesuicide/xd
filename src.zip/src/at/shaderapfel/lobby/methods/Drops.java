package at.shaderapfel.lobby.methods;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.utils.ItemUtils;

public class Drops {

	public static BukkitTask task;

	public static void startItemDrop(Player p, String type) {

		if (type.equalsIgnoreCase("gold")) {

			task = new BukkitRunnable() {

				@Override
				public void run() {
					if (Bukkit.getOnlinePlayers().contains(p) && Main.golddrops.contains(p)) {
						Item i1 = p.getLocation().getWorld().dropItem(p.getLocation(),
								ItemUtils.getItem(Material.GOLD_INGOT, p.getName(), " ", 0, 1));

						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								i1.remove();

							}
						}, 10);

						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								Item i2 = p.getLocation().getWorld().dropItem(p.getLocation(),
										ItemUtils.getItem(Material.GOLD_NUGGET, p.getName(), " ", 0, 1));
								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										i2.remove();

									}
								}, 10);

							}
						}, 2);
						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								Item i3 = p.getLocation().getWorld().dropItem(p.getLocation(),
										ItemUtils.getItem(Material.BLAZE_ROD, p.getName(), " ", 0, 1));
								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										i3.remove();

									}
								}, 10);

							}
						}, 2);
						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								Item i4 = p.getLocation().getWorld().dropItem(p.getLocation(),
										ItemUtils.getItem(Material.GLOWSTONE_DUST, p.getName(), " ", 0, 1));
								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										i4.remove();

									}
								}, 10);

							}
						}, 2);

					}

				}

			}.runTaskTimer(Main.instance, 0, 8);

		} else if (type.equalsIgnoreCase("red")) {

			task = new BukkitRunnable() {

				@Override
				public void run() {
					if (Bukkit.getOnlinePlayers().contains(p) && Main.reddrops.contains(p)) {
						Item i1 = p.getLocation().getWorld().dropItem(p.getLocation(),
								ItemUtils.getItem(Material.REDSTONE, p.getName(), " ", 0, 1));

						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								i1.remove();

							}
						}, 10);

						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								Item i2 = p.getLocation().getWorld().dropItem(p.getLocation(),
										ItemUtils.getItem(Material.REDSTONE_BLOCK, p.getName(), " ", 0, 1));
								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										i2.remove();

									}
								}, 10);

							}
						}, 2);
						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								Item i3 = p.getLocation().getWorld().dropItem(p.getLocation(),
										ItemUtils.getItem(Material.SPIDER_EYE, p.getName(), " ", 0, 1));
								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										i3.remove();

									}
								}, 10);

							}
						}, 2);
						Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

							@Override
							public void run() {
								Item i4 = p.getLocation().getWorld().dropItem(p.getLocation(),
										new ItemStack(Material.WOOL, 1, (short) 14));
								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										i4.remove();

									}
								}, 10);

							}
						}, 2);

					}

				}

			}.runTaskTimer(Main.instance, 0, 8);

		}

	}
}
