package at.shaderapfel.lobby.utils;

import at.shaderapfel.lobby.Main;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

/**
 * Created by shaderapfel on 18.02.17.
 */
public class BungeeUtils{

    public static void teleportPlayer(Player p, String targetServer) {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("Connect");
        out.writeUTF(targetServer);

        p.sendPluginMessage(Main.instance, "BungeeCord", out.toByteArray());


    }


}
