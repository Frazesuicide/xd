package at.shaderapfel.lobby.utils;

import at.shaderapfel.lobby.Main;

import java.sql.ResultSet;
import java.sql.SQLException;

import static at.shaderapfel.lobby.Main.instance;


public class SQLApi {

    public static boolean playerExists(String uuid) {

        try {
            ResultSet rs = instance.mysql.query("SELECT * FROM Stats WHERE UUID= '" + uuid + "'");

            if (rs.next()) {
                return rs.getString("UUID") != null;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void createPlayer(String uuid) {

        if (!(playerExists(uuid))) {
            instance.mysql.update("INSERT INTO Stats(UUID, SJOIN, COINS) VALUES ('" + uuid + "', '0', '0');");
        }
    }

    public static Integer getCoins(String uuid) {
        Integer i = 0;

        if (playerExists(uuid)) {
            try {
                ResultSet rs = instance.mysql.query("SELECT * FROM Stats WHERE UUID= '" + uuid + "'");
                if ((!rs.next()) || (Integer.valueOf(rs.getInt("COINS")) == null)) ;

                i = rs.getInt("COINS");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            createPlayer(uuid);
            getCoins(uuid);
        }
        return i;
    }

    public static Boolean silentJoinActivated(String uuid) {
        Integer i = 0;

        if (playerExists(uuid)) {
            try {
                ResultSet rs = instance.mysql.query("SELECT * FROM Stats WHERE UUID= '" + uuid + "'");
                if ((!rs.next()) || (Integer.valueOf(rs.getInt("SJOIN")) == null)) ;

                i = rs.getInt("SJOIN");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            createPlayer(uuid);
            silentJoinActivated(uuid);
        }
        if (i == 0) {
            return false;
        } else if (i == 1) {
            return true;
        } else {
            System.out.println("SCHWERWIEGENDER FEHLER: SilentJoin ist weder 0 noch 1! Kontaktiere den Entwickler des Systems!");
            return false;
        }
    }

    public static void setCoins(String uuid, Integer coins) {
        if (playerExists(uuid)) {
            instance.mysql.update("UPDATE Stats SET COINS= '" + coins + "' WHERE UUID= '" + uuid + "';");
        } else {
            createPlayer(uuid);
            setCoins(uuid, coins);
        }
    }

    public static void setSilentJoin(String uuid, Boolean enable) {
        if (playerExists(uuid)) {
            if (enable) {
                instance.mysql.update("UPDATE Stats SET SJOIN= '1' WHERE UUID= '" + uuid + "';");
            } else {
                instance.mysql.update("UPDATE Stats SET SJOIN= '0' WHERE UUID= '" + uuid + "';");
            }

        } else {
            createPlayer(uuid);
            setSilentJoin(uuid, enable);
        }
    }

    public static void addCoins(String uuid, Integer coins) {
        if (playerExists(uuid)) {
            if (coins > 0) {
                setCoins(uuid, Integer.valueOf(getCoins(uuid).intValue() + coins.intValue()));
            }
        } else {
            createPlayer(uuid);
            addCoins(uuid, coins);
        }
    }

    public static void removeCoins(String uuid, Integer coins) {
        if (playerExists(uuid)) {
            if (getCoins(uuid) - coins >= 0 && coins < 0)
                setCoins(uuid, Integer.valueOf(getCoins(uuid).intValue() - coins.intValue()));
        } else {
            createPlayer(uuid);
            removeCoins(uuid, coins);
        }
    }
}