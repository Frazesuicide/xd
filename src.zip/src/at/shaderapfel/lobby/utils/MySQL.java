package at.shaderapfel.lobby.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.bukkit.Bukkit;

public class MySQL {

	private String HOST = "";
	private String DATABASE = "";
	private String USER = "";
	private String PASSWORD = "";

	private Connection con;

	public MySQL(String host, String database, String user, String password) {
		this.HOST = host;
		this.DATABASE = database;
		this.USER = user;
		this.PASSWORD = password;

		connect();
	}

	public void connect() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://" + HOST + ":3306/" + DATABASE + "?autoReconnect=true", USER, PASSWORD);
			Bukkit.getConsoleSender().sendMessage("§7» §aDie Verbindung zur MySQL Datenbank wurde erfolgreich aufgebaut");
		} catch (SQLException e) {
			Bukkit.getConsoleSender().sendMessage("§7» §cFehler beim Verbindungsaufbau zur Datenbank!");
			Bukkit.getConsoleSender().sendMessage("§7» §cBitte Zugangsdaten überprüfen und erneut versuchen!");
		}
	}

	public void close() {
		try {
			if(con != null) {
				con.close();
				Bukkit.getConsoleSender().sendMessage("§7» §aDie Verbindung zur Datenbank wurde aufgelöst!");
			}
		} catch (SQLException e) {
			Bukkit.getConsoleSender().sendMessage("§7» §cFehler beim auflösen der MySQL-Verbindung! Meldung: " + e.getMessage());
		}
	}

	public void update(String qry) {
		try {
			Statement st = con.createStatement();
			st.executeUpdate(qry);
			st.close();
		} catch (SQLException e) {
			connect();
			System.err.println(e);
		}
	}

	public ResultSet query(String qry) {
		ResultSet rs = null;

		try {
			Statement st = con.createStatement();
			rs = st.executeQuery(qry);
		} catch (SQLException e) {
			connect();
			System.err.println(e);
		}
		return rs;
	}
}