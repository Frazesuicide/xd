package at.shaderapfel.lobby.manager;

import at.shaderapfel.lobby.utils.SQLApi;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import at.shaderapfel.lobby.Main;

public class ScoreboardManager {

    @SuppressWarnings("deprecation")
    public static void setScoreboard(Player p) {

        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("aaa", "bbb");
        obj.setDisplayName(Main.sbtitle);
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        obj.getScore(Main.sb1).setScore(10);
        obj.getScore(Main.sb2).setScore(9);
        obj.getScore(Main.sb3).setScore(8);
        obj.getScore(Main.sb4).setScore(7);
        obj.getScore(Main.sb5).setScore(6);

        if (Main.rankhidden.contains(p)) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankspieler)).setScore(5);
        } else if (p.hasPermission("lobby.admin")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankadmin)).setScore(5);

        } else if (p.hasPermission("lobby.developer")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankdev)).setScore(5);

        } else if (p.hasPermission("lobby.srmoderator")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.ranksrmod)).setScore(5);

        } else if (p.hasPermission("lobby.moderator")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankmod)).setScore(5);

        } else if (p.hasPermission("lobby.supporter")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.ranksupporter)).setScore(5);

        } else if (p.hasPermission("lobby.builder")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankbuilder)).setScore(5);

        } else if (p.hasPermission("lobby.youtuber")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankyoutuber)).setScore(5);

        } else if (p.hasPermission("lobby.premiumplus")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankminiyoutuber)).setScore(5);

        } else if (p.hasPermission("lobby.ultimate")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankultimate)).setScore(5);

        } else if (p.hasPermission("lobby.elite")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankelite)).setScore(5);

        } else if (p.hasPermission("lobby.plus")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankplus)).setScore(5);

        } else if (p.hasPermission("lobby.spieler")) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankspieler)).setScore(5);

        } else if (p.isOp()) {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankadmin)).setScore(5);
        } else {
            obj.getScore(Main.sb6.replaceAll("%rank%", Main.rankspieler)).setScore(5);
        }

        obj.getScore(Main.sb7).setScore(4);
        obj.getScore(Main.sb8).setScore(3);
        Integer coins = SQLApi.getCoins(p.getUniqueId().toString());

        String s = Main.sb9.replaceAll("%coins%", coins.toString());
        obj.getScore(s).setScore(2);
        obj.getScore(Main.sb10).setScore(1);

        Team admin = sb.registerNewTeam("000admin");
        admin.setPrefix("§4A §8┃ §7");

        Team developer = sb.registerNewTeam("001developer");
        developer.setPrefix("§bD §8┃ §7");

        Team srmoderator = sb.registerNewTeam("002srmoderator");
        srmoderator.setPrefix("§cSM §8┃ §7");

        Team moderator = sb.registerNewTeam("003moderator");
        moderator.setPrefix("§cM §8┃ §7");

        Team supporter = sb.registerNewTeam("004supporter");
        supporter.setPrefix("§aS §8┃ §7");

        Team builder = sb.registerNewTeam("005builder");
        builder.setPrefix("§9B §8┃ §7");

        Team youtuber = sb.registerNewTeam("006youtuber");
        youtuber.setPrefix("§5YT §8┃ §7");

        Team premiumplus = sb.registerNewTeam("007premiumplus");
        premiumplus.setPrefix("§5MYT §8┃ §7");

        Team ultimate = sb.registerNewTeam("008ultimate");
        ultimate.setPrefix("§bU §8┃ §7");

        Team elite = sb.registerNewTeam("009elite");
        elite.setPrefix("§6E §8┃ §7");

        Team plus = sb.registerNewTeam("010plus");
        plus.setPrefix("§3P §8┃ §7");

        Team spieler = sb.registerNewTeam("011spieler");
        spieler.setPrefix("§eS §8┃ §7");

        for (Player all : Bukkit.getOnlinePlayers()) {
            if (Main.rankhidden.contains(all)) {
                spieler.addPlayer(all);
            } else if (all.hasPermission("lobby.admin")) {
                admin.addPlayer(all);
            } else if (all.hasPermission("lobby.developer")) {
                developer.addPlayer(all);
            } else if (all.hasPermission("lobby.srmoderator")) {
                srmoderator.addPlayer(all);
            } else if (all.hasPermission("lobby.moderator")) {
                moderator.addPlayer(all);
            } else if (all.hasPermission("lobby.supporter")) {
                supporter.addPlayer(all);
            } else if (all.hasPermission("lobby.builder")) {
                builder.addPlayer(all);
            } else if (all.hasPermission("lobby.youtuber")) {
                youtuber.addPlayer(all);
            } else if (all.hasPermission("lobby.premiumplus")) {
                premiumplus.addPlayer(all);
            } else if (all.hasPermission("lobby.ultimate")) {
                ultimate.addPlayer(all);
            } else if (all.hasPermission("lobby.elite")) {
                elite.addPlayer(all);
            } else if (all.hasPermission("lobby.plus")) {
                plus.addPlayer(all);
            } else if (all.hasPermission("lobby.spieler")) {
                spieler.addPlayer(all);
            } else if (p.isOp()) {
                admin.addPlayer(all);
            } else {
                spieler.addPlayer(all);
            }
        }

        p.setScoreboard(sb);

    }

}
