package at.shaderapfel.lobby.listener;

import org.bukkit.Material;
import org.bukkit.block.Skull;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.LocationAPI;

public class Build implements Listener {

	@EventHandler
	public void on(BlockPlaceEvent event) {
		Player player = event.getPlayer();
		if (Main.buildmode.contains(player)) {
			event.setCancelled(false);
			if (event.getBlock().equals(Material.SKULL)) {
				Skull s = (Skull) event.getBlock();
				if (s.getOwner().equals("MHF_Question")) {
					if (LocationAPI.cfg.contains("secret")) {
						LocationAPI.setLocation(s.getLocation(), "secret" + LocationAPI.cfg.getInt("secretsset") + 1);
					} else {
						LocationAPI.setLocation(s.getLocation(), "secret.1");
					}
				}

			}
		} else {
			event.setCancelled(true);
		}

	}

	@EventHandler
	public void on(BlockBreakEvent event) {
		Player player = event.getPlayer();
		if (Main.buildmode.contains(player)) {
			event.setCancelled(false);
		} else {
			event.setCancelled(true);
		}

	}

}
