package at.shaderapfel.lobby.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.JoinItems;

public class InvClose implements Listener {

	@EventHandler
	public void on(InventoryCloseEvent event) {
		Player player = (Player) event.getPlayer();
		if (!Main.buildmode.contains(player)) {
			JoinItems.giveJoinItems(player);
		}
	}
}
