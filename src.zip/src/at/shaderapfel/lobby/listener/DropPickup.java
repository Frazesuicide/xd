package at.shaderapfel.lobby.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

import at.shaderapfel.lobby.Main;

public class DropPickup implements Listener{
	
	@EventHandler
	public void on(PlayerDropItemEvent event){
		if(Main.buildmode.contains(event.getPlayer())){
			event.setCancelled(false);
		}else{
			event.setCancelled(true);
		}
	}
	
	@EventHandler
	public void on(PlayerPickupItemEvent event){
		if(Main.buildmode.contains(event.getPlayer())){
			event.setCancelled(false);
		}else{
			event.setCancelled(true);
		}
	}

}
