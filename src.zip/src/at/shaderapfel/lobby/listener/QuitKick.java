package at.shaderapfel.lobby.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import at.shaderapfel.lobby.Main;

public class QuitKick implements Listener {

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();

		if (Main.buildmode.contains(p)) {
			Main.buildmode.remove(p);
		}
		if (Main.fly.contains(p)) {
			Main.fly.remove(p);
		}
		if (Main.rankhidden.contains(p)) {
			Main.rankhidden.remove(p);
		}

		e.setQuitMessage(null);
	}

	@EventHandler
	public void onKick(PlayerKickEvent e) {
		Player p = e.getPlayer();

		if (Main.buildmode.contains(p)) {
			Main.buildmode.remove(p);
		} else if (Main.fly.contains(p)) {
			Main.fly.remove(p);
		}
		if (Main.rankhidden.contains(p)) {
			Main.rankhidden.remove(p);
		}

		e.setLeaveMessage(null);
	}

}
