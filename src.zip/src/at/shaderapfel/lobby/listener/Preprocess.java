package at.shaderapfel.lobby.listener;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import at.shaderapfel.lobby.Main;

public class Preprocess implements Listener {

    @EventHandler
    public void on(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();

        if (e.isCancelled()) {
            p.sendMessage(Main.prefix + "§7Der Command §8[§c" + e.getMessage() + "§8] §7existiert nicht!");
            p.sendMessage(Main.prefix + "§7Bitte führe §e§l/hilfe &7aus!");
        } else if (e.getMessage().contains("/help") || e.getMessage().contains("/bukkit:help")
                || e.getMessage().contains("/?") || e.getMessage().contains("/bukkit:?")
                || e.getMessage().contains("/bukkit:help") || e.getMessage().contains("/bukkit:pl")
                || e.getMessage().contains("/pl") || e.getMessage().contains("/plugins")
                || e.getMessage().contains("/bukkit:version") || e.getMessage().contains("/bukkit:ver")
                || e.getMessage().contains("/bukkit:plugins")) {
            e.setCancelled(true);
            p.sendMessage(Main.help1);
            p.sendMessage(Main.help2);
            p.sendMessage(Main.help3);
            p.sendMessage(Main.help4);
            p.sendMessage(Main.help5);
            p.sendMessage(Main.help6);
            p.sendMessage(Main.help7);
            p.sendMessage(Main.help8);

            p.playSound(p.getLocation(), Sound.ORB_PICKUP, 1, 1);

        }
    }

}
