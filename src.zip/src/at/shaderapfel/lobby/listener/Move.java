package at.shaderapfel.lobby.listener;

import at.shaderapfel.lobby.methods.LocationAPI;
import org.bukkit.Effect;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import at.shaderapfel.lobby.Main;

public class Move implements Listener {

    @EventHandler
    public void on(PlayerMoveEvent e) {
        Player p = e.getPlayer();

        if (Main.flametrail.contains(p)) {
            p.getWorld().playEffect(p.getLocation(), Effect.MOBSPAWNER_FLAMES, 1);
        } else if (Main.lovetrail.contains(p)) {
            p.getWorld().playEffect(p.getLocation(), Effect.HEART, 1);
        } else if (Main.smoketrail.contains(p)) {
            p.getWorld().playEffect(p.getLocation(), Effect.LAVA_POP, 1);
        }

        if (p.getLocation().getY() <= 0) {
            p.teleport(LocationAPI.getLocation("spawn"));
            p.playSound(p.getLocation(), Sound.ENDERMAN_TELEPORT, 1, 1);
        }

    }

}
