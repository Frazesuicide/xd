package at.shaderapfel.lobby.listener;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;

import at.shaderapfel.lobby.Main;

public class InvClickKleiderschrank implements Listener {

	@EventHandler
	public void on(InventoryClickEvent event) {

		Player player = (Player) event.getWhoClicked();
		
		ItemStack helm1 = new ItemStack(Material.LEATHER_HELMET);
		LeatherArmorMeta helmmeta1 = (LeatherArmorMeta) helm1.getItemMeta();
		helmmeta1.setColor(Color.RED);
		helmmeta1.setDisplayName("§cRoter Helm");
		helm1.setItemMeta(helmmeta1);

		ItemStack chest1 = new ItemStack(Material.LEATHER_CHESTPLATE);
		LeatherArmorMeta chestmeta1 = (LeatherArmorMeta) chest1.getItemMeta();
		chestmeta1.setColor(Color.RED);
		chestmeta1.setDisplayName("§cRote Brustplatte");
		chest1.setItemMeta(chestmeta1);

		ItemStack leggins1 = new ItemStack(Material.LEATHER_LEGGINGS);
		LeatherArmorMeta legginsmeta1 = (LeatherArmorMeta) leggins1.getItemMeta();
		legginsmeta1.setColor(Color.RED);
		legginsmeta1.setDisplayName("§cRote Hose");
		leggins1.setItemMeta(legginsmeta1);

		ItemStack boots1 = new ItemStack(Material.LEATHER_BOOTS);
		LeatherArmorMeta bootsmeta1 = (LeatherArmorMeta) boots1.getItemMeta();
		bootsmeta1.setColor(Color.RED);
		bootsmeta1.setDisplayName("§cRote Schuhe");
		boots1.setItemMeta(bootsmeta1);

		ItemStack helm11 = new ItemStack(Material.LEATHER_HELMET);
		LeatherArmorMeta helmmeta11 = (LeatherArmorMeta) helm11.getItemMeta();
		helmmeta11.setColor(Color.AQUA);
		helmmeta11.setDisplayName("§3Türkiser Helm");
		helm11.setItemMeta(helmmeta11);

		ItemStack chest11 = new ItemStack(Material.LEATHER_CHESTPLATE);
		LeatherArmorMeta chestmeta11 = (LeatherArmorMeta) chest11.getItemMeta();
		chestmeta11.setColor(Color.AQUA);
		chestmeta11.setDisplayName("§3Türkise Brustplatte");
		chest11.setItemMeta(chestmeta11);

		ItemStack leggins11 = new ItemStack(Material.LEATHER_LEGGINGS);
		LeatherArmorMeta legginsmeta11 = (LeatherArmorMeta) leggins11.getItemMeta();
		legginsmeta11.setColor(Color.AQUA);
		legginsmeta11.setDisplayName("§3Türkise Hose");
		leggins11.setItemMeta(legginsmeta11);

		ItemStack boots11 = new ItemStack(Material.LEATHER_BOOTS);
		LeatherArmorMeta bootsmeta11 = (LeatherArmorMeta) boots11.getItemMeta();
		bootsmeta11.setColor(Color.AQUA);
		bootsmeta11.setDisplayName("§3Türkise Schuhe");
		boots11.setItemMeta(bootsmeta11);

		ItemStack helm111 = new ItemStack(Material.LEATHER_HELMET);
		LeatherArmorMeta helmmeta111 = (LeatherArmorMeta) helm111.getItemMeta();
		helmmeta111.setColor(Color.GREEN);
		helmmeta111.setDisplayName("§aGrüner Helm");
		helm111.setItemMeta(helmmeta111);

		ItemStack chest111 = new ItemStack(Material.LEATHER_CHESTPLATE);
		LeatherArmorMeta chestmeta111 = (LeatherArmorMeta) chest111.getItemMeta();
		chestmeta111.setColor(Color.GREEN);
		chestmeta111.setDisplayName("§aGrüne Brustplatte");
		chest111.setItemMeta(chestmeta111);

		ItemStack leggins111 = new ItemStack(Material.LEATHER_LEGGINGS);
		LeatherArmorMeta legginsmeta111 = (LeatherArmorMeta) leggins111.getItemMeta();
		legginsmeta111.setColor(Color.GREEN);
		legginsmeta111.setDisplayName("§aGrüne Hose");
		leggins111.setItemMeta(legginsmeta111);

		ItemStack boots111 = new ItemStack(Material.LEATHER_BOOTS);
		LeatherArmorMeta bootsmeta111 = (LeatherArmorMeta) boots111.getItemMeta();
		bootsmeta111.setColor(Color.GREEN);
		bootsmeta111.setDisplayName("§aGrüne Schuhe");
		boots111.setItemMeta(bootsmeta111);

		ItemStack helm1111 = new ItemStack(Material.LEATHER_HELMET);
		LeatherArmorMeta helmmeta1111 = (LeatherArmorMeta) helm1111.getItemMeta();
		helmmeta1111.setColor(Color.WHITE);
		helmmeta1111.setDisplayName("§fWeißer Helm");
		helm1111.setItemMeta(helmmeta1111);

		ItemStack chest1111 = new ItemStack(Material.LEATHER_CHESTPLATE);
		LeatherArmorMeta chestmeta1111 = (LeatherArmorMeta) chest1111.getItemMeta();
		chestmeta1111.setColor(Color.WHITE);
		chestmeta1111.setDisplayName("§fWeiße Brustplatte");
		chest1111.setItemMeta(chestmeta1111);

		ItemStack leggins1111 = new ItemStack(Material.LEATHER_LEGGINGS);
		LeatherArmorMeta legginsmeta1111 = (LeatherArmorMeta) leggins1111.getItemMeta();
		legginsmeta1111.setColor(Color.WHITE);
		legginsmeta1111.setDisplayName("§fWeiße Hose");
		leggins1111.setItemMeta(legginsmeta1111);

		ItemStack boots1111 = new ItemStack(Material.LEATHER_BOOTS);
		LeatherArmorMeta bootsmeta1111 = (LeatherArmorMeta) boots1111.getItemMeta();
		bootsmeta1111.setColor(Color.WHITE);
		bootsmeta1111.setDisplayName("§fWeiße Schuhe");
		boots1111.setItemMeta(bootsmeta1111);

		if (Main.buildmode.contains(player)) {
			event.setCancelled(false);
		} else {
			event.setCancelled(true);

			if (event.getInventory().getName().equalsIgnoreCase("§6Kleiderschrank")) {
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cRoter Helm")){
					player.getInventory().setHelmet(helm1);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cRote Brustplatte")){
					player.getInventory().setChestplate(chest1);		
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);			
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cRote Hose")){
					player.getInventory().setLeggings(leggins1);
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);					
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cRote Schuhe")){
					player.getInventory().setBoots(boots1);
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);					
				}
				
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§3Türkiser Helm")){
					player.getInventory().setHelmet(helm11);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§3Türkise Brustplatte")){
					player.getInventory().setChestplate(chest11);
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);					
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§3Türkise Hose")){
					player.getInventory().setLeggings(leggins11);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§3Türkise Schuhe")){
					player.getInventory().setBoots(boots11);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				

				
				
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aGrüner Helm")){
					player.getInventory().setHelmet(helm111);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aGrüne Brustplatte")){
					player.getInventory().setChestplate(chest111);
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);					
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aGrüne Hose")){
					player.getInventory().setLeggings(leggins111);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aGrüne Schuhe")){
					player.getInventory().setBoots(boots111);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				
				
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§fWeißer Helm")){
					player.getInventory().setHelmet(helm1111);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§fWeiße Brustplatte")){
					player.getInventory().setChestplate(chest1111);
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);					
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§fWeiße Hose")){
					player.getInventory().setLeggings(leggins1111);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§fWeiße Schuhe")){
					player.getInventory().setBoots(boots1111);	
					player.playSound(player.getLocation(), Sound.CLICK, 1, 1);				
				}
				
				
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cHelm entfernen")){
					player.getInventory().setHelmet(null);	
					player.playSound(player.getLocation(), Sound.NOTE_BASS, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBrustplatte entfernen")){
					player.getInventory().setChestplate(null);
					player.playSound(player.getLocation(), Sound.NOTE_BASS, 1, 1);					
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cHose entfernen")){
					player.getInventory().setLeggings(null);	
					player.playSound(player.getLocation(), Sound.NOTE_BASS, 1, 1);				
				}
				if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cSchuhe entfernen")){
					player.getInventory().setBoots(null);	
					player.playSound(player.getLocation(), Sound.NOTE_BASS, 1, 1);				
				}
			}
		}
	}

}
