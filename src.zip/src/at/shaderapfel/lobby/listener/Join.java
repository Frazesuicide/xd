package at.shaderapfel.lobby.listener;

import at.shaderapfel.lobby.utils.SQLApi;
import at.shaderapfel.lobby.utils.TabUtils;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffectType;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.manager.ScoreboardManager;
import at.shaderapfel.lobby.methods.JoinItems;
import at.shaderapfel.lobby.methods.Prefix;

public class Join implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();

        e.setJoinMessage(null);

        for (Player all : Bukkit.getOnlinePlayers()) {
            ScoreboardManager.setScoreboard(all);
        }

        if (!p.hasPlayedBefore()) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

                @Override
                public void run() {
                    Bukkit.dispatchCommand(p, "spawn");

                }
            }, 5);
        }

        p.setMaxHealth(10);
        p.setLevel(0);
        p.setExp(0);
        p.setHealth(10);
        p.setFoodLevel(20);
        p.setGameMode(GameMode.ADVENTURE);
        p.getInventory().clear();
        Prefix.setPrefix(p);
        TabUtils.sendTabTitle(p, Main.tabheader, Main.tabfooter);
        if(p.hasPermission("lobby.fly")){
            p.setAllowFlight(true);
        }
        SQLApi.createPlayer(p.getUniqueId().toString());
        p.sendMessage(Main.joinMotd);
        if (p.hasPermission("lobby.joinBroadcast")) {
            p.sendMessage("§aDu möchtest SilentJoin aktivieren / deaktivieren?");
            p.sendMessage("§7» §e/silentjoin <on/off>");
        }
        if (p.hasPermission("lobby.joinBroadcast")) {
            if (!SQLApi.silentJoinActivated(p.getUniqueId().toString())) {
                Bukkit.broadcastMessage(Main.staffJoinBroadcast.replaceAll("%name%", p.getName()));
            }
        }

        // HALLOWEEN

//		p.getInventory().setHelmet(ItemUtils.getItem(Material.JACK_O_LANTERN, "§6HALLOWEEN FEATURE", "§7Dieses Feature wird\n§7nach Halloween wieder\n§7entfernt! Also genieße es ;)", 0, 1));
//		p.getWorld().playSound(p.getLocation(), Sound.BAT_DEATH, 1, 1);
//		p.getWorld().playEffect(p.getLocation(), Effect.WITCH_MAGIC, 1);
        p.sendTitle("§6" + Main.servername, "§7Dein Servernetzwerk!");
        if (p.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
            p.removePotionEffect(PotionEffectType.INVISIBILITY);
        }
        if (p.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
            p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }

//		p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 1000000, 1, true, true));

        // HALLOWEEN AUS

        JoinItems.giveJoinItems(p);

//		p.sendMessage(" ");
//		p.sendMessage("§3Willkommen, " + p.getDisplayName());
//		p.sendMessage(" ");

        Main.playersall.add(p);

        for (Player all : Bukkit.getOnlinePlayers()) {
            if (Main.playersnone.contains(all)) {
                all.hidePlayer(p);
            } else if (Main.playersvip.contains(all)) {
                if ((!p.hasPermission("lobby.vip")) || Main.rankhidden.contains(p)) {
                    all.hidePlayer(p);
                }
            }
            if (Main.rankhidden.contains(all)) {
                all.hidePlayer(p);
            }
        }
    }
}
