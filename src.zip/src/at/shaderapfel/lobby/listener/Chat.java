package at.shaderapfel.lobby.listener;

import at.shaderapfel.lobby.Main;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class Chat implements Listener {

	@EventHandler
	public void onChat(AsyncPlayerChatEvent e) {
		Player p = e.getPlayer();
		String msg = e.getMessage();
		if(!Main.IsSilentHub){
			if (p.hasPermission("server.colorchat")) {
				e.setCancelled(true);
				Bukkit.broadcastMessage(" §8● " + p.getDisplayName() + " §8» §f" + msg.replaceAll("&", "§"));
			} else {
				e.setCancelled(true);
				Bukkit.broadcastMessage(" §8● " + p.getDisplayName() + " §8» §f" + msg);
			}
		}else{
			e.setCancelled(true);
			p.sendMessage(Main.prefix+"§cIn der SilentHub kann nicht geschrieben werden!");
		}


	}

}
