package at.shaderapfel.lobby.listener;

import at.shaderapfel.lobby.utils.BungeeUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.Drops;
import at.shaderapfel.lobby.methods.Inventories;
import at.shaderapfel.lobby.methods.JoinItems;
import at.shaderapfel.lobby.utils.ItemUtils;

public class InvClick implements Listener {

    @EventHandler
    public void on(InventoryClickEvent event) {

        Player player = (Player) event.getWhoClicked();

        if (Main.buildmode.contains(player)) {
            event.setCancelled(false);
        } else {
            event.setCancelled(true);

            if (event.getInventory().getName().equalsIgnoreCase("§6Navigator")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem1Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem1WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem2Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem2WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem3Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem3WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem4Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem4WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem5Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem5WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem6Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem6WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem7Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem7WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem8Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem8WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.WarpItem9Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem9WarpName);
                    JoinItems.giveJoinItems(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase(Main.WarpItem10Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem10WarpName);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase(Main.WarpItem11Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem11WarpName);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase(Main.WarpItem12Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem12WarpName);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase(Main.WarpItem13Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem13WarpName);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase(Main.WarpItem14Name)) {
                    Bukkit.dispatchCommand(player, "warp " + Main.WarpItem14WarpName);
                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§6Sichtbarkeit")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aAlle Spieler anzeigen")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    player.sendMessage(Main.allplayer);
                    player.closeInventory();
                    JoinItems.giveJoinItems(player);
                    if (!Main.playersall.contains(player)) {
                        Main.playersall.add(player);
                        for (Player all : Bukkit.getOnlinePlayers()) {
                            player.showPlayer(all);
                        }
                        if (Main.playersvip.contains(player)) {
                            Main.playersvip.remove(player);
                        }
                        if (Main.playersnone.contains(player)) {
                            Main.playersnone.remove(player);
                        }
                    }
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§5VIP Spieler anzeigen")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    player.sendMessage(Main.vipplayer);
                    player.closeInventory();
                    JoinItems.giveJoinItems(player);
                    if (!Main.playersvip.contains(player)) {
                        Main.playersvip.add(player);
                        for (Player all : Bukkit.getOnlinePlayers()) {
                            if ((!all.hasPermission("lobby.vip")) || Main.rankhidden.contains(player)) {
                                player.hidePlayer(all);
                            }
                        }
                        if (Main.playersall.contains(player)) {
                            Main.playersall.remove(player);
                        }
                        if (Main.playersnone.contains(player)) {
                            Main.playersnone.remove(player);
                        }
                    }
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§cKeine Spieler anzeigen")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    player.sendMessage(Main.noplayer);
                    player.closeInventory();
                    JoinItems.giveJoinItems(player);
                    for (Player all : Bukkit.getOnlinePlayers()) {
                        player.hidePlayer(all);
                    }
                    if (!Main.playersnone.contains(player)) {
                        Main.playersnone.add(player);
                        if (Main.playersvip.contains(player)) {
                            Main.playersvip.remove(player);
                        }
                        if (Main.playersall.contains(player)) {
                            Main.playersall.remove(player);
                        }
                    }
                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§6Profil")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Gadgets")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    if (Main.gadgetsEnabled) {
                        Inventories.openGadgets(player);
                    } else {
                        player.sendMessage(Main.prefix + "§cDie Gadgets sind derzeit deaktiviert!");
                    }
//					Inventories.setGlass(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aFreunde")) {
                    if (Main.friendsboolean) {
                        player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                        Bukkit.dispatchCommand(player, Main.friendscommand);
//						Inventories.setGlass(player);
                    } else {
                        player.sendMessage(Main.prefix + "§cDas Freundesystem ist derzeit deaktiviert!");
                    }

                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eKleiderschrank")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    Inventories.openKleiderschrank(player);
//					Inventories.setGlass(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eLobby-Switcher")) {
                    if(Main.lobbyswitcherEnabled){
                        player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                        Inventories.openLobbySwitcher(player);
                    }else{
                        player.sendMessage(Main.prefix + "§cDer LobbySwitcher ist derzeit deaktiviert!");
                    }
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§2Effekt-Items")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    Inventories.openDrops(player);
//					Inventories.setGlass(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§3Köpfe")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    Inventories.openHeads(player);
//					Inventories.setGlass(player);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cTrails")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    Inventories.openTrails(player);
//					Inventories.setGlass(player);
                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§6Gadgets")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§bEnderperle §8× §7Gadget")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    player.sendMessage(Main.gadget.replaceAll("%gadget%", "Enderperle"));
                    if (Main.jumpboost.contains(player)) {
                        Main.jumpboost.remove(player);
                    }
                    if (Main.mysticcannon.contains(player)) {
                        Main.mysticcannon.remove(player);
                    }
                    if (Main.snowball.contains(player)) {
                        Main.snowball.remove(player);
                    }
                    Main.enderpearl.add(player);
                    player.closeInventory();
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§bJumpBoost §8× §7Gadget")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    player.sendMessage(Main.gadget.replaceAll("%gadget%", "JumpBoost"));
                    if (Main.enderpearl.contains(player)) {
                        Main.enderpearl.remove(player);
                    }
                    if (Main.mysticcannon.contains(player)) {
                        Main.mysticcannon.remove(player);
                    }
                    if (Main.snowball.contains(player)) {
                        Main.snowball.remove(player);
                    }
                    Main.jumpboost.add(player);
                    player.closeInventory();
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§cGadget entfernen!")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    if (Main.enderpearl.contains(player)) {
                        Main.enderpearl.remove(player);
                    }
                    if (Main.jumpboost.contains(player)) {
                        Main.jumpboost.remove(player);
                    }
                    if (Main.mysticcannon.contains(player)) {
                        Main.mysticcannon.remove(player);
                    }
                    if (Main.snowball.contains(player)) {
                        Main.snowball.remove(player);
                    }
                    player.closeInventory();
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§6Mystic Cannon §8× §7Halloween-Gadget")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    if (Main.enderpearl.contains(player)) {
                        Main.enderpearl.remove(player);
                    }
                    if (Main.jumpboost.contains(player)) {
                        Main.jumpboost.remove(player);
                    }
                    if (Main.snowball.contains(player)) {
                        Main.snowball.remove(player);
                    }
                    Main.mysticcannon.add(player);

                    player.closeInventory();
                } else if (event.getCurrentItem().getItemMeta().getDisplayName()
                        .equalsIgnoreCase("§f§lSchneeball §8× §7Weihnachts-Gadget")) {
                    player.playSound(player.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
                    if (Main.enderpearl.contains(player)) {
                        Main.enderpearl.remove(player);
                    }
                    if (Main.jumpboost.contains(player)) {
                        Main.jumpboost.remove(player);
                    }
                    if (Main.mysticcannon.contains(player)) {
                        Main.mysticcannon.remove(player);
                    }
                    Main.snowball.add(player);

                    player.closeInventory();
                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§6Drop-Effekte")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Golden")) {
                    if (Main.reddrops.contains(player)) {
                        Main.reddrops.remove(player);
                    }
                    if (!Main.golddrops.contains(player)) {
                        Main.golddrops.add(player);
                        player.sendMessage(Main.prefix + "§7Du hast den §6goldenen Drop-Effekt §7ausgewählt");
                        Inventories.openDrops(player);
//						Inventories.setGlass(player);
                        player.playSound(player.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);
                        Drops.startItemDrop(player, "gold");
                    } else {
                        Main.golddrops.remove(player);
                        player.sendMessage(Main.prefix + "§7Du hast den §6goldenen Drop-Effekt §7entfernt");
                        Inventories.openDrops(player);
//						Inventories.setGlass(player);
                        Drops.task.cancel();

                    }

                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cRot")) {
                    if (Main.golddrops.contains(player)) {
                        Main.golddrops.remove(player);
                    }
                    if (!Main.reddrops.contains(player)) {
                        Main.reddrops.add(player);
                        player.sendMessage(Main.prefix + "§7Du hast den §croten Drop-Effekt §7ausgewählt");
                        Inventories.openDrops(player);
//						Inventories.setGlass(player);
                        player.playSound(player.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);
                        Drops.startItemDrop(player, "red");
                    } else {
                        Main.reddrops.remove(player);
                        player.sendMessage(Main.prefix + "§7Du hast den §croten Drop-Effekt §7entfernt");
                        Inventories.openDrops(player);
//						Inventories.setGlass(player);
                        Drops.task.cancel();

                    }

                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§6Trails")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Flammen")) {
                    if (Main.lovetrail.contains(player)) {
                        Main.lovetrail.remove(player);
                    }
                    if (Main.smoketrail.contains(player)) {
                        Main.smoketrail.remove(player);
                    }
                    if (!Main.flametrail.contains(player)) {
                        Main.flametrail.add(player);
                        player.sendMessage(Main.prefix + "§7Du hast das §6§l§oFlammen-Trail §7ausgewählt");
                        Inventories.openTrails(player);
//						Inventories.setGlass(player);
                        player.playSound(player.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);
                    } else {
                        Main.flametrail.remove(player);
                        player.sendMessage(Main.prefix + "§7Du hast das §6§l§oFlammen-Trail §7entfernt");
                        Inventories.openTrails(player);
//						Inventories.setGlass(player);

                    }

                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cHerzen")) {
                    if (Main.flametrail.contains(player)) {
                        Main.flametrail.remove(player);
                    }
                    if (Main.smoketrail.contains(player)) {
                        Main.smoketrail.remove(player);
                    }
                    if (!Main.lovetrail.contains(player)) {
                        Main.lovetrail.add(player);
                        player.sendMessage(Main.prefix + "§7Du hast das §c§l§oHerz-Trail §7ausgewählt");
                        Inventories.openTrails(player);
//						Inventories.setGlass(player);
                        player.playSound(player.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);
                    } else {
                        Main.lovetrail.remove(player);
                        player.sendMessage(Main.prefix + "§7Du hast das §c§l§oHerz-Trail §7entfernt");
                        Inventories.openTrails(player);
//						Inventories.setGlass(player);

                    }

                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§7Rauch")) {
                    if (Main.flametrail.contains(player)) {
                        Main.flametrail.remove(player);
                    }
                    if (Main.lovetrail.contains(player)) {
                        Main.lovetrail.remove(player);
                    }
                    if (!Main.smoketrail.contains(player)) {
                        Main.smoketrail.add(player);
                        player.sendMessage(Main.prefix + "§7Du hast das §7§l§oRauch-Trail §7ausgewählt");
                        Inventories.openTrails(player);
//						Inventories.setGlass(player);
                        player.playSound(player.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);
                    } else {
                        Main.smoketrail.remove(player);
                        player.sendMessage(Main.prefix + "§7Du hast das §7§l§oRauch-Trail §7entfernt");
                        Inventories.openTrails(player);
//						Inventories.setGlass(player);

                    }

                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§6Köpfe")) {
                if (event.getCurrentItem().getType().equals(Material.SKULL_ITEM)) {
                    if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cZurück")) {
                        Inventories.openProfil(player);
                    } else {
                        String lore = event.getCurrentItem().getItemMeta().getLore().get(0).replaceAll("§eKopf von §7",
                                "");
                        player.getInventory().setHelmet(ItemUtils.getHead(lore,
                                event.getCurrentItem().getItemMeta().getDisplayName(), "§cKopf", 1));
                        player.closeInventory();
                        player.playSound(player.getLocation(), Sound.CAT_MEOW, 1, 1);
                    }
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cKopf entfernen")) {
                    player.getInventory().setHelmet(null);
                }
            } else if (event.getInventory().getName().equalsIgnoreCase("§eLobby-Switcher")) {
                if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eLobby 1")) {
                    BungeeUtils.teleportPlayer(player, Main.Server1Name);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eLobby 2")) {
                    BungeeUtils.teleportPlayer(player, Main.Server2Name);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eLobby 3")) {
                    BungeeUtils.teleportPlayer(player, Main.Server3Name);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eLobby 4")) {
                    BungeeUtils.teleportPlayer(player, Main.Server4Name);
                } else if (event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eSilentHub")) {
                    BungeeUtils.teleportPlayer(player, Main.SilentHubName);
                }
            }
        }
    }

}
