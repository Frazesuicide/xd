package at.shaderapfel.lobby.interact;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import at.shaderapfel.lobby.Main;

public class flymode implements Listener {

	@EventHandler
	public void onCompass(PlayerInteractEvent e) {
		Player p = e.getPlayer();

		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if (p.getItemInHand().getType() == Material.getMaterial(Main.flymodeid)) {
				if(p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("§aFlugmodus §8× §7Rechtsklick") || p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("§cFlugmodus §8× §7Rechtsklick")){
					ItemStack flyon = new ItemStack(Material.getMaterial(Main.flymodeid));
					ItemMeta flyonmeta = flyon.getItemMeta();
					flyonmeta.setDisplayName("§aFlugmodus §8× §7Rechtsklick");
					flyon.setItemMeta(flyonmeta);

					ItemStack flyoff = new ItemStack(Material.getMaterial(Main.flymodeid));
					ItemMeta flyoffmeta = flyoff.getItemMeta();
					flyoffmeta.setDisplayName("§cFlugmodus §8× §7Rechtsklick");
					flyoff.setItemMeta(flyoffmeta);

					if (!Main.fly.contains(p)) {
						Main.fly.add(p);
						p.sendMessage(Main.flymodeon);
						p.setAllowFlight(true);
						p.playSound(p.getLocation(), Sound.NOTE_PLING, 1, 1);
						if (p.hasPermission("lobby.2")) {
							p.getInventory().setItem(4, flyon);
						} else if (p.hasPermission("lobby.3")) {
							p.getInventory().setItem(2, flyon);
						} else if (p.hasPermission("lobby.4")) {
							p.getInventory().setItem(4, flyon);
						}
						p.updateInventory();

					} else if (Main.fly.contains(p)) {
						Main.fly.remove(p);
						p.setAllowFlight(false);
						p.sendMessage(Main.flymodeoff);
						p.playSound(p.getLocation(), Sound.NOTE_PLING, 1, 1);

						if (p.hasPermission("lobby.2")) {
							p.getInventory().setItem(4, flyoff);
						} else if (p.hasPermission("lobby.3")) {
							p.getInventory().setItem(2, flyoff);
						} else if (p.hasPermission("lobby.4")) {
							p.getInventory().setItem(4, flyoff);
						}
						p.updateInventory();
					}
				}
			}
		}
	}
}
