package at.shaderapfel.lobby.interact;

import at.shaderapfel.lobby.Main;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import at.shaderapfel.lobby.methods.Inventories;

public class profil implements Listener {

	@EventHandler
	public void onCompass(PlayerInteractEvent e) {
		Player p = e.getPlayer();

		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if (p.getItemInHand().getType() == Material.SKULL_ITEM) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Profil §8× §7Rechtsklick")) {
					if(Main.profilEnabled){
						Inventories.openProfil(p);
					}else{
						p.sendMessage(Main.prefix+"§cDas Profil ist derzeit deaktiviert!");
					}
				}
			}
		}
	}

}
