package at.shaderapfel.lobby.interact;

import at.shaderapfel.lobby.Main;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import at.shaderapfel.lobby.methods.Inventories;

public class compass implements Listener {

	@EventHandler
	public void onCompass(PlayerInteractEvent e) {
		Player p = e.getPlayer();

		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if (p.getItemInHand().getType() == Material.getMaterial(Main.compassid)) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Navigator §8× §7Rechtsklick")) {
					Inventories.openCompass(p);
				}
			}
		}
	}

}
