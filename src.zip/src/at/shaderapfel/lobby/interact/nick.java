package at.shaderapfel.lobby.interact;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import at.shaderapfel.lobby.Main;

public class nick implements Listener {

	@EventHandler
	public void onCompass(PlayerInteractEvent e) {
		Player p = e.getPlayer();

		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if (p.getItemInHand().getType() == Material.NAME_TAG) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cNick §8× §7Rechtsklick")) {
					if (p.hasPermission("lobby.3")) {
						Main.nickname.add(p);

						ItemStack i1 = new ItemStack(Material.NAME_TAG);
						ItemMeta i1m = i1.getItemMeta();
						i1m.setDisplayName("§aNick §8× §7Rechtsklick");
						i1.setItemMeta(i1m);

						p.updateInventory();
						p.getInventory().setItem(6, i1);

						p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 3.0F, 3.0F);
						p.sendMessage(Main.nickan);

					} else if (p.hasPermission("lobby.4")) {
						Main.nickname.remove(p);

						ItemStack i1 = new ItemStack(Material.NAME_TAG);
						ItemMeta i1m = i1.getItemMeta();
						i1m.setDisplayName("§aNick §8× §7Rechtsklick");
						i1.setItemMeta(i1m);

						p.updateInventory();
						p.getInventory().setItem(6, i1);

						p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 3.0F, 3.0F);
						p.sendMessage(Main.nickan);

					}
				}
			}
		}
		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if (p.getItemInHand().getType() == Material.NAME_TAG) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aNick §8× §7Rechtsklick")) {
					if (p.hasPermission("lobby.3")) {
						Main.nickname.add(p);

						ItemStack i1 = new ItemStack(Material.NAME_TAG);
						ItemMeta i1m = i1.getItemMeta();
						i1m.setDisplayName("§cNick §8× §7Rechtsklick");
						i1.setItemMeta(i1m);

						p.updateInventory();
						p.getInventory().setItem(6, i1);

						p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 3.0F, 3.0F);
						p.sendMessage(Main.nickaus);

					} else if (p.hasPermission("lobby.4")) {
						Main.nickname.add(p);

						ItemStack i1 = new ItemStack(Material.NAME_TAG);
						ItemMeta i1m = i1.getItemMeta();
						i1m.setDisplayName("§cNick §8× §7Rechtsklick");
						i1.setItemMeta(i1m);

						p.updateInventory();
						p.getInventory().setItem(6, i1);

						p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 3.0F, 3.0F);
						p.sendMessage(Main.nickaus);

					}
				}
			}
		}
	}
}
