package at.shaderapfel.lobby.interact;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import at.shaderapfel.lobby.methods.Inventories;

public class zertrampeln implements Listener {

	@EventHandler
	public void onZertrampel(PlayerInteractEvent e) {
		Player p = e.getPlayer();

		if (e.getAction() == Action.PHYSICAL && e.getClickedBlock().getType().equals(Material.SOIL)) {
			e.setCancelled(true);
		}
	}

}
