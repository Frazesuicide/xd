package at.shaderapfel.lobby.interact;

import at.shaderapfel.lobby.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import at.shaderapfel.lobby.methods.Inventories;

public class customitem implements Listener {

    @EventHandler
    public void onCustomItem(PlayerInteractEvent e) {
        Player p = e.getPlayer();

        if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (p.getItemInHand().getType() == Material.getMaterial(Main.customItemId)) {
                if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.customItemDisplayName)) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Main.customItemCmd.replaceAll("%player%", p.getName()));
                }
            }
        }
    }

}
