package at.shaderapfel.lobby.interact;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import at.shaderapfel.lobby.Main;
import at.shaderapfel.lobby.methods.Inventories;
import at.shaderapfel.lobby.utils.ItemUtils;

public class gadget implements Listener {

	@EventHandler
	public void onGadget(PlayerInteractEvent e) {
		Player p = e.getPlayer();

		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if (p.getItemInHand().getType() == Material.getMaterial(Main.nogadgetid)) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Kein Gadget §8× §7Rechtsklick")) {
					if(Main.gadgetsEnabled){
						Inventories.openGadgets(p);
					}else{
						p.sendMessage(Main.prefix+"§cDie Gadgets sind derzeit deaktiviert!");
					}
				}
			} else if (p.getItemInHand().getType() == Material.ENDER_PEARL) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§bEnderperle §8× §7Gadget")) {

					p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
					p.getInventory().setItem(7,
							ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach.", "§6Gadget", 0, 1));
					Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

						@Override
						public void run() {
							p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
							p.getInventory().setItem(7,
									ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach..", "§6Gadget", 0, 1));
							Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

								@Override
								public void run() {
									p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
									p.getInventory().setItem(7, ItemUtils.getItem(Material.FIREWORK_CHARGE,
											"§7Lade nach...", "§6Gadget", 0, 1));
									Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

										@Override
										public void run() {
											p.playSound(p.getLocation(), Sound.ORB_PICKUP, 1, 1);
											p.getInventory().setItem(7, ItemUtils.getItem(Material.ENDER_PEARL,
													"§bEnderperle §8× §7Gadget", "§6Gadget", 0, 1));

										}
									}, 10);
								}
							}, 10);
						}
					}, 10);
				}
			} else if (p.getItemInHand().getType() == Material.SLIME_BALL) {
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§bJumpBoost §8× §7Gadget")) {

					Vector v = p.getLocation().getDirection().multiply(2.5D).setY(1);
					p.setVelocity(v);

					p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 1, 1);
					p.getInventory().setItem(7,
							ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach.", "§6Gadget", 0, 1));
					Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

						@Override
						public void run() {
							p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
							p.getInventory().setItem(7,
									ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach..", "§6Gadget", 0, 1));
							Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

								@Override
								public void run() {
									p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
									p.getInventory().setItem(7, ItemUtils.getItem(Material.FIREWORK_CHARGE,
											"§7Lade nach...", "§6Gadget", 0, 1));
									Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

										@Override
										public void run() {
											p.playSound(p.getLocation(), Sound.ORB_PICKUP, 1, 1);
											p.getInventory().setItem(7, ItemUtils.getItem(Material.SLIME_BALL,
													"§bJumpBoost §8× §7Gadget", "§6Gadget", 0, 1));

										}
									}, 10);
								}
							}, 10);
						}
					}, 10);
				}
			} else if (p.getItemInHand().getType() == Material.BLAZE_ROD) {
				if (e.getItem().getItemMeta().getDisplayName()
						.equalsIgnoreCase("§6Mystic Cannon §8× §7Halloween-Gadget")) {

					Item item = p.getLocation().getWorld().dropItem(p.getEyeLocation(), new ItemStack(Material.COAL));

					Vector v = p.getLocation().getDirection().multiply(1);
					item.setVelocity(v);

					Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

						@Override
						public void run() {
							item.getWorld().createExplosion(item.getLocation().getX(), item.getLocation().getY(),
									item.getLocation().getZ(), 3, false, false);
							item.getWorld().playEffect(item.getLocation().add(0, 1, 0), Effect.EXPLOSION_LARGE, 1);
							item.getWorld().playEffect(item.getLocation().add(1, 0, 0), Effect.EXPLOSION_LARGE, 1);
							item.getWorld().playEffect(item.getLocation().add(0, 0, 1), Effect.EXPLOSION_LARGE, 1);
							item.getWorld().playEffect(item.getLocation(), Effect.FIREWORKS_SPARK, 1);
							item.getWorld().playSound(item.getLocation(), Sound.BAT_DEATH, 1, 1);
							item.getWorld().playSound(item.getLocation(), Sound.EXPLODE, 1, 1);
							Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

								@Override
								public void run() {
									item.getWorld().playSound(item.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);

								}
							}, 3);
						}
					}, 20);

					p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);
					p.getInventory().setItem(7,
							ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach.", "§6Gadget", 0, 1));
					Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

						@Override
						public void run() {
							p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
							p.getInventory().setItem(7,
									ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach..", "§6Gadget", 0, 1));
							Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

								@Override
								public void run() {
									p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
									p.getInventory().setItem(7, ItemUtils.getItem(Material.FIREWORK_CHARGE,
											"§7Lade nach...", "§6Gadget", 0, 1));
									Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

										@Override
										public void run() {
											p.playSound(p.getLocation(), Sound.ORB_PICKUP, 1, 1);
											p.getInventory().setItem(7, ItemUtils.getItem(Material.BLAZE_ROD,
													"§6Mystic Cannon §8× §7Halloween-Gadget", "§6Gadget", 0, 1));

										}
									}, 10);
								}
							}, 10);
						}
					}, 10);
				}
			} else if (p.getItemInHand().getType() == Material.SNOW_BALL) {
				if (e.getItem().getItemMeta().getDisplayName()
						.equalsIgnoreCase("§f§lSchneeball §8× §7Weihnachts-Gadget")) {

					e.setCancelled(true);
					Item item = p.getLocation().getWorld().dropItem(p.getEyeLocation(),
							new ItemStack(Material.SNOW_BALL));

					Vector v = p.getLocation().getDirection().multiply(1);
					item.setVelocity(v);

					Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

						@Override
						public void run() {
							item.getWorld().createExplosion(item.getLocation().getX(), item.getLocation().getY(),
									item.getLocation().getZ(), 3, false, false);
							item.getWorld().playEffect(item.getLocation().add(0, 1, 0), Effect.EXPLOSION_LARGE, 1);
							item.getWorld().playEffect(item.getLocation().add(1, 0, 0), Effect.EXPLOSION_LARGE, 1);
							item.getWorld().playEffect(item.getLocation().add(0, 0, 1), Effect.EXPLOSION_LARGE, 1);
							for (Player all : Bukkit.getOnlinePlayers()) {
								if (all.getLocation().distance(item.getLocation()) <= 6) {
									Vector v = all.getLocation().getDirection().setY(3).multiply(2);

									all.setVelocity(v);
								}
							}
							item.getWorld().playEffect(item.getLocation(), Effect.FIREWORKS_SPARK, 1);
							item.getWorld().playSound(item.getLocation(), Sound.GLASS, 1, 1);
							Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

								@Override
								public void run() {
									item.getWorld().playSound(item.getLocation(), Sound.FIREWORK_TWINKLE, 1, 1);

								}
							}, 3);
						}
					}, 20);

					p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);
					p.getInventory().setItem(7,
							ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach.", "§6Gadget", 0, 1));
					Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

						@Override
						public void run() {
							p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
							p.getInventory().setItem(7,
									ItemUtils.getItem(Material.FIREWORK_CHARGE, "§7Lade nach..", "§6Gadget", 0, 1));
							Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

								@Override
								public void run() {
									p.playSound(p.getLocation(), Sound.CLICK, 1, 1);
									p.getInventory().setItem(7, ItemUtils.getItem(Material.FIREWORK_CHARGE,
											"§7Lade nach...", "§6Gadget", 0, 1));
									Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new Runnable() {

										@Override
										public void run() {
											p.playSound(p.getLocation(), Sound.ORB_PICKUP, 1, 1);
											p.getInventory().setItem(7, ItemUtils.getItem(Material.SNOW_BALL,
													"§f§lSchneeball §8× §7Weihnachts-Gadget", "§6Gadget", 0, 1));

										}
									}, 10);
								}
							}, 10);
						}
					}, 10);
				}
			}

		}
	}

}
